# ChronoSync BLE: Direct Standalone APK Download Implementation Plan

This update provides a direct, error-free `.apk` file download served directly from the application's own origin (`/chronosync-ble.apk`), as well as an in-browser client-side APK package generator, bypassing third-party crawlers (like PWABuilder) that trigger authentication or network errors.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Root Cause of External APK Builder Errors**: External bot services (such as PWABuilder) fail when attempting to crawl preview domains because they cannot pass through AI Studio's session gate. 
> To guarantee **zero errors**, we serve the `.apk` file **directly from the app's own web server** and provide an instant in-browser APK generator that packages the file on your device.

- **Direct Download Link**: `https://ais-dev-tojaopw564uawai3zvh2pv-936609393261.asia-southeast1.run.app/chronosync-ble.apk`
- **Zero Third-Party Relays**: No external converters or crawler bots required.
- **Header Action**: Dedicated "Download .APK" button placed directly in the main top bar for 1-click access.

---

## 1. Overview & Core Solution

1. **Direct Static `.apk` Asset**:
   - Host `public/chronosync-ble.apk` directly on the web server with `Content-Type: application/vnd.android.package-archive` and `Content-Disposition: attachment; filename="chronosync-ble.apk"`.
   - Clicking the link triggers the native Android package installer download immediately in Chrome.
2. **Instant In-Browser APK Builder (Client-Side Fallback)**:
   - If a direct file download is ever blocked by network carrier filters, the user can click **"Download APK"** inside the app.
   - Using client-side `JSZip` and Web Blob packaging, the app compiles the Android package assets (`AndroidManifest.xml`, icons, and PWA launcher) into a `.apk` file in device RAM and triggers a local file save without touching the internet.
3. **Dedicated Top-Bar Action**:
   - Add a prominent, high-visibility button in Zone 3 of the header: `[Download .APK]`.
   - When tapped on an Android phone, it immediately starts the file download.

---

## 2. User Experience & Visual Design

- **Top Navigation Bar**:
  - Adds a green/blue highlighted button: `Download .APK`.
  - On desktop and mobile, one tap initiates the direct `.apk` file download to the Android `Downloads/` folder.
- **Android Installation Dialog**:
  - Highlights the direct APK download link with a single tap.
  - Includes a 2-step prompt for Android:
    1. Tap **"Download .APK"**.
    2. Tap **"Open"** when the download finishes, and tap **"Install"** in Android's package installer.

---

## 3. Technical Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          CHRONOSYNC BLE DIRECT APK                          │
├─────────────────────────────────────────────────────────────────────────────┤
│  Browser / Android Chrome                                                   │
│    │                                                                        │
│    ├──► Direct Link: /chronosync-ble.apk ──► Origin Web Server              │
│    │                                          └──► Returns Android Package  │
│    │                                                                        │
│    └──► In-App Client APK Generator ──► JSZip Blob                          │
│                                           └──► Saves .apk directly to disk  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Verification & Acceptance Criteria

1. Navigating to `/chronosync-ble.apk` triggers an immediate file download on Chrome and Android.
2. Tapping "Download .APK" in the header initiates the APK package download without any third-party redirects or 401/404 errors.
3. Complete direct links are provided directly in the chat response.
