/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type BluetoothConnectionState = 
  | 'disconnected'
  | 'scanning'
  | 'connecting'
  | 'connected'
  | 'error';

export type ColorMode = 
  | 'rgb565'     // 16-bit (5-6-5), 2 bytes per pixel
  | 'rgb332'     // 8-bit (3-3-2), 1 byte per pixel
  | 'grayscale'  // 4-bit / 8-bit grayscale
  | 'monochrome'; // 1-bit black & white

export type CropMode = 
  | 'center-crop'
  | 'letterbox'
  | 'cursor-track';

export interface WatchHardwareProfile {
  name: string;
  versionString: string;
  branch: string;
  buildTime: string;
  serialNumber: string;
  mreVersion: string;
  nativeWidth: number;
  nativeHeight: number;
  colorDepth: number; // bits
  screenDiagonalInches: number;
  displayType: string;
}

export interface StreamEncodingSettings {
  targetResolution: 128 | 240;
  fpsLimit: number;
  colorMode: ColorMode;
  cropMode: CropMode;
  useDeltaCompression: boolean;
  tileSize: number; // e.g. 16px
  mtuSize: number; // e.g. 20 (BLE 4.0) or 244 (BLE 4.2+)
  pacingIntervalMs: number; // delay between BLE packets
  brightness: number; // 0.5 to 1.5
  contrast: number; // 0.5 to 1.5
  invertColors: boolean;
}

export interface BlePacketLogItem {
  id: string;
  timestamp: number;
  seq: number;
  type: 'FRAME_START' | 'TILE_DELTA' | 'FULL_CHUNK' | 'FRAME_END' | 'HEARTBEAT' | 'HANDSHAKE';
  sizeBytes: number;
  hexSample: string;
  target: 'physical_ble' | 'simulator_loopback';
}

export interface TelemetryMetrics {
  currentFps: number;
  dataRateKbps: number;
  totalBytesTransmitted: number;
  totalPacketsSent: number;
  framesRendered: number;
  droppedPackets: number;
  bandwidthSavedPercent: number;
  deltaTilesSent: number;
  totalTilesInFrame: number;
  uncompressedFrameSizeBytes: number;
  compressedFrameSizeBytes: number;
}
