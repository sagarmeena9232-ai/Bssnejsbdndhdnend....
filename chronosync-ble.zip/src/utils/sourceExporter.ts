/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';

export async function exportProjectZip(): Promise<void> {
  const zip = new JSZip();

  // Root files
  zip.file('package.json', JSON.stringify({
    name: "chronosync-ble",
    private: true,
    version: "1.0.0",
    type: "module",
    scripts: {
      dev: "vite",
      build: "tsc -b && vite build",
      preview: "vite preview"
    },
    dependencies: {
      "lucide-react": "^0.546.0",
      "react": "^19.0.1",
      "react-dom": "^19.0.1",
      "jszip": "^3.10.1"
    },
    devDependencies: {
      "@tailwindcss/vite": "^4.3.3",
      "@types/node": "^22.14.0",
      "@types/react": "^19.3.0",
      "@types/react-dom": "^19.3.0",
      "@types/jszip": "^3.4.1",
      "@vitejs/plugin-react": "^6.1.1",
      "tailwindcss": "^4.3.3",
      "typescript": "^5.7.0",
      "vite": "^6.0.0"
    }
  }, null, 2));

  zip.file('index.html', `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ChronoSync BLE</title>
    <link rel="manifest" href="/manifest.json" />
    <link rel="icon" type="image/svg+xml" href="/icon.svg" />
  </head>
  <body class="bg-[#090D16] text-slate-100 antialiased">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`);

  zip.file('README.md', `# ChronoSync BLE (1.44" Smartwatch Streamer)

Sync your computer or Android screen directly to a 1.44" Bluetooth smartwatch (MediaTek GL6113 / BL6133 / MX6XM-1.44).

## 100% Offline Peer-to-Peer Bluetooth
- No internet or Wi-Fi is used or needed on the watch.
- Uses Web Bluetooth API (\`navigator.bluetooth\`) for direct local GATT packet streaming.
- Real-time 16-bit RGB565 / RGB332 quantization and 16x16 delta-tile compression to fit BLE radio bandwidth.

## Quick Start
1. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
2. Run development server:
   \`\`\`bash
   npm run dev
   \`\`\`
3. Open in Google Chrome, Microsoft Edge, or Chrome on Android.
4. Turn ON Bluetooth on your 1.44" watch and tap **"Connect Bluetooth Watch"**!
`);

  zip.file('vite.config.ts', `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
});`);

  zip.file('tsconfig.json', `{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "jsx": "react-jsx",
    "skipLibCheck": true,
    "strict": false
  }
}`);

  // Generate ZIP and trigger browser download
  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'chronosync-ble-source.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
