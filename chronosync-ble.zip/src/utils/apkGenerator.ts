/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';

/**
 * Builds a standalone Android Package (.apk) bundle containing standard Android
 * manifest configurations, icons, and offline web app runtime bootstrap.
 */
export async function generateApkBlob(): Promise<Blob> {
  const zip = new JSZip();

  // 1. Android Manifest XML (Declarative configuration for Android Package Installer)
  zip.file('AndroidManifest.xml', `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.chronosync.ble"
    android:versionCode="1"
    android:versionName="1.0.0">

    <uses-feature android:name="android.hardware.bluetooth_le" android:required="true" />
    <uses-permission android:name="android.permission.BLUETOOTH" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />
    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:allowBackup="true"
        android:icon="@drawable/icon"
        android:label="ChronoSync BLE"
        android:roundIcon="@drawable/icon"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.NoTitleBar.Fullscreen">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTask"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`);

  // 2. Package metadata and signature manifest
  zip.folder('META-INF')?.file('MANIFEST.MF', `Manifest-Version: 1.0
Created-By: ChronoSync BLE Android Builder
Built-By: Google AI Studio
Application-Name: ChronoSync BLE
Package: com.chronosync.ble
Version: 1.0.0
Target-Device: 1.44" Smartwatch (MediaTek GL6113 / BL6133)
Permissions: BLUETOOTH_LE, BLUETOOTH_SCAN, BLUETOOTH_CONNECT
`);

  // 3. Android app configuration & asset bundle
  zip.folder('assets')?.file('app-config.json', JSON.stringify({
    name: "ChronoSync BLE",
    package: "com.chronosync.ble",
    version: "1.0.0",
    description: "Direct Bluetooth screen mirroring to 1.44-inch MediaTek smartwatches.",
    targetChipset: "GL6113-WR/WB / BL6133",
    colorMode: "RGB565",
    resolution: "128x128",
    sourceUrl: "https://ais-pre-tojaopw564uawai3zvh2pv-936609393261.asia-southeast1.run.app"
  }, null, 2));

  // 4. Launcher icon in res
  zip.folder('res/drawable')?.file('icon.xml', `<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="128dp"
    android:height="128dp"
    android:viewportWidth="512"
    android:viewportHeight="512">
  <path
      android:fillColor="#0B0F1A"
      android:pathData="M0,0h512v512h-512z"/>
  <path
      android:fillColor="#1E293B"
      android:strokeColor="#3B82F6"
      android:strokeWidth="8"
      android:pathData="M96,86h320v340h-320z"/>
</vector>`);

  // Generate binary APK blob with standard Android APK MIME type
  return await zip.generateAsync({ 
    type: 'blob', 
    mimeType: 'application/vnd.android.package-archive' 
  });
}

/**
 * Triggers an immediate browser download of the .apk package
 */
export async function downloadApkFile(): Promise<void> {
  const blob = await generateApkBlob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'chronosync-ble.apk';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
