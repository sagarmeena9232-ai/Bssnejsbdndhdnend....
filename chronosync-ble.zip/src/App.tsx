/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  BluetoothConnectionState, 
  StreamEncodingSettings, 
  TelemetryMetrics 
} from './types/bluetooth';
import { bleSyncEngine, USER_WATCH_PROFILE } from './services/bleProtocol';
import { ScreenCaptureEngine } from './components/ScreenCaptureEngine';
import { WatchBezelSimulator } from './components/WatchBezelSimulator';
import { EncodingControls } from './components/EncodingControls';
import { BluetoothManager } from './components/BluetoothManager';
import { TelemetryInspector } from './components/TelemetryInspector';
import { InstallDownloadModal } from './components/InstallDownloadModal';
import { usePWAInstall } from './hooks/usePWAInstall';
import { downloadApkFile } from './utils/apkGenerator';
import { 
  Watch, 
  WifiOff, 
  Layers, 
  Sliders, 
  Terminal, 
  HelpCircle,
  ExternalLink,
  ShieldCheck,
  Zap,
  Info,
  Download,
  Smartphone,
  Sparkles,
  Package
} from 'lucide-react';

export default function App() {
  const [connectionState, setConnectionState] = useState<BluetoothConnectionState>('disconnected');
  const [connectedDeviceName, setConnectedDeviceName] = useState<string>('');
  const [isStreaming, setIsStreaming] = useState<boolean>(true);
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);
  const [showInstallModal, setShowInstallModal] = useState<boolean>(false);
  const [isDownloadingApk, setIsDownloadingApk] = useState<boolean>(false);

  const { isInstallable, isInstalled } = usePWAInstall();

  // Streaming & Encoding Configuration
  const [settings, setSettings] = useState<StreamEncodingSettings>({
    targetResolution: 128, // native 1.44" GL6113 resolution
    fpsLimit: 3,           // optimal for BLE radio bandwidth (~4-8 KB/s)
    colorMode: 'rgb565',   // 16-bit 5-6-5 color
    cropMode: 'center-crop',
    useDeltaCompression: true,
    tileSize: 16,
    mtuSize: 20,
    pacingIntervalMs: 15,
    brightness: 1.0,
    contrast: 1.0,
    invertColors: false
  });

  // Real-time telemetry metrics
  const [telemetry, setTelemetry] = useState<TelemetryMetrics>({
    currentFps: 0,
    dataRateKbps: 0,
    totalBytesTransmitted: 0,
    totalPacketsSent: 0,
    framesRendered: 0,
    droppedPackets: 0,
    bandwidthSavedPercent: 0,
    deltaTilesSent: 0,
    totalTilesInFrame: 64,
    uncompressedFrameSizeBytes: 32768,
    compressedFrameSizeBytes: 0
  });

  // Listen for Bluetooth connection state changes
  useEffect(() => {
    const unsubscribe = bleSyncEngine.onConnectionChange((state, deviceName) => {
      setConnectionState(state);
      if (deviceName) setConnectedDeviceName(deviceName);
    });

    return () => unsubscribe();
  }, []);

  const handleTelemetryUpdate = (metrics: Partial<TelemetryMetrics>) => {
    setTelemetry(prev => ({ ...prev, ...metrics }));
  };

  const handleDirectApkDownload = async (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    try {
      setIsDownloadingApk(true);
      await downloadApkFile();
    } catch (err) {
      console.error('Failed to generate APK:', err);
      // Fallback to static URL
      window.location.href = '/chronosync-ble.apk';
    } finally {
      setTimeout(() => setIsDownloadingApk(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* 1. Universal Top Bar Contract: [Brand title] — [Nav links] — [Primary action] */}
      <header className="sticky top-0 z-40 bg-[#0B0F1A]/95 border-b border-slate-800/80 backdrop-blur-md px-3 sm:px-4 lg:px-8 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
          
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-900/40 border border-blue-400/30">
              <Watch className="w-4 h-4 text-white" />
            </div>
            <a href="/" className="text-sm sm:text-base font-bold tracking-tight text-white flex items-center gap-1.5 sm:gap-2">
              <span>ChronoSync BLE</span>
              <span className="text-[10px] text-blue-400 font-mono font-medium border border-blue-500/30 px-1.5 py-0.5 rounded">
                1.44" MRE
              </span>
            </a>
          </div>

          {/* Zone 2: Clean text navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
            <a href="#monitor" className="hover:text-slate-100 transition-colors">Screen Source</a>
            <a href="#simulator" className="hover:text-slate-100 transition-colors">Hardware Watch</a>
            <a href="#compression" className="hover:text-slate-100 transition-colors">Compression</a>
            <a href="#telemetry" className="hover:text-slate-100 transition-colors">Packet Stream</a>
            <button 
              onClick={() => setShowHelpModal(true)}
              className="flex items-center gap-1 hover:text-slate-100 transition-colors text-slate-400"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Offline Guide</span>
            </button>
          </nav>

          {/* Zone 3: Primary Actions (Download APK + Bluetooth) */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Direct 1-Click APK Download Button */}
            <button
              onClick={handleDirectApkDownload}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white shadow-md shadow-emerald-950/40 border border-emerald-400/40 transition-colors cursor-pointer"
              title="Download standalone Android APK directly to your device"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isDownloadingApk ? 'Downloading...' : 'Download .APK'}</span>
            </button>

            {/* Install / Download Center button */}
            <button
              onClick={() => setShowInstallModal(true)}
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                isInstalled
                  ? 'bg-slate-800/80 text-emerald-300 border-emerald-500/40 hover:bg-slate-800'
                  : 'bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white border-slate-700'
              }`}
              title="Open install options & links"
            >
              <Smartphone className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">Links</span>
            </button>

            {/* Bluetooth connection trigger */}
            <BluetoothManager
              connectionState={connectionState}
              deviceName={connectedDeviceName}
            />
          </div>
        </div>
      </header>

      {/* Prominent Mobile APK Download Quick-Bar */}
      <div className="sm:hidden bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border-b border-emerald-700/60 px-3 py-2 flex items-center justify-between gap-2 shadow-inner">
        <div className="flex items-center gap-1.5 min-w-0">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <span className="text-[11px] font-medium text-emerald-200 truncate">
            Android APK Ready for Download
          </span>
        </div>
        <button
          onClick={handleDirectApkDownload}
          className="shrink-0 px-2.5 py-1 bg-emerald-600 active:bg-emerald-700 text-white font-bold text-[11px] rounded flex items-center gap-1 shadow"
        >
          <Download className="w-3 h-3" />
          <span>Tap to Download</span>
        </button>
      </div>

      {/* Offline Architecture Verification Banner */}
      <div className="bg-gradient-to-r from-blue-950/40 via-slate-900 to-blue-950/40 border-b border-slate-800/80 px-4 py-2">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span className="font-semibold text-slate-200">100% Peer-to-Peer Bluetooth</span>
            <span className="text-slate-500">·</span>
            <span className="text-slate-400">
              No internet or Wi-Fi required on the watch. Frames stream directly through local BLE GATT characteristics.
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400">
            <span>Model: <strong className="text-slate-200">{USER_WATCH_PROFILE.name}</strong></span>
            <span>·</span>
            <span>FW: <strong className="text-slate-200">GL6113-WR/WB</strong></span>
          </div>
        </div>
      </div>

      {/* Main Content Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-6 space-y-6">
        
        {/* Top Dual Stage: Source Screen on Left, 1.44" Watch on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[500px]">
          
          {/* Left Column: Screen Capture Source */}
          <div id="monitor" className="lg:col-span-7 flex flex-col">
            <ScreenCaptureEngine
              settings={settings}
              onTelemetryUpdate={handleTelemetryUpdate}
              isStreaming={isStreaming}
              setIsStreaming={setIsStreaming}
            />
          </div>

          {/* Right Column: 1.44" Physical Watch Hardware Simulator */}
          <div id="simulator" className="lg:col-span-5 flex flex-col">
            <WatchBezelSimulator
              connectionState={connectionState}
              deviceName={connectedDeviceName}
              settings={settings}
              fps={telemetry.currentFps}
              dataRateKbps={telemetry.dataRateKbps}
            />
          </div>
        </div>

        {/* Middle Stage: Compression & Stream Tuning Controls */}
        <section id="compression">
          <EncodingControls
            settings={settings}
            setSettings={setSettings}
          />
        </section>

        {/* Bottom Stage: Telemetry & Live Packet Inspector */}
        <section id="telemetry">
          <TelemetryInspector
            metrics={telemetry}
          />
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-[#070B12] py-4 px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">ChronoSync BLE</span>
            <span>·</span>
            <span>MediaTek MRE Wearable Protocol Engine (GL6113 / BL6133)</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500">
            <button
              onClick={handleDirectApkDownload}
              className="hover:text-emerald-400 text-emerald-500/90 transition-colors flex items-center gap-1 font-medium"
            >
              <Download className="w-3 h-3" />
              <span>Download .APK</span>
            </button>
            <span>·</span>
            <button
              onClick={() => setShowInstallModal(true)}
              className="hover:text-slate-300 transition-colors flex items-center gap-1"
            >
              <Smartphone className="w-3 h-3 text-blue-400" />
              <span>Android Links & Install</span>
            </button>
            <span>·</span>
            <span>Direct GATT Radio Transmission</span>
            <span>·</span>
            <span>RGB565 Bit-Packing</span>
          </div>
        </div>
      </footer>

      {/* Android Download & Installation Modal */}
      <InstallDownloadModal
        isOpen={showInstallModal}
        onClose={() => setShowInstallModal(false)}
      />

      {/* Offline Bluetooth Pairing Guide Modal */}
      {showHelpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
              <div className="flex items-center gap-2">
                <WifiOff className="w-4 h-4 text-blue-400" />
                <h3 className="font-semibold text-slate-100 text-sm">How ChronoSync BLE Connects to Your Watch</h3>
              </div>
              <button 
                onClick={() => setShowHelpModal(false)}
                className="text-slate-400 hover:text-white px-2 py-1 rounded hover:bg-slate-800 text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs text-slate-300 leading-relaxed">
              <div className="p-3 bg-blue-950/40 border border-blue-800/40 rounded-lg text-blue-200">
                <div className="flex items-center gap-1.5 font-semibold text-sm mb-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>No Internet Connection Needed</span>
                </div>
                Your 1.44" watch has no Wi-Fi or cellular chip. All communication takes place strictly peer-to-peer over your computer's or Android device's built-in Bluetooth adapter using the Web Bluetooth API.
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold text-slate-100 text-sm">Step-by-Step Connection Instructions:</h4>
                <ol className="list-decimal list-inside space-y-2 text-slate-300">
                  <li>
                    <strong className="text-slate-100">Power on your smartwatch</strong> and swipe to the Settings / Bluetooth menu. Ensure Bluetooth is switched <strong className="text-emerald-400">ON</strong> and set to Visible / Discoverable.
                  </li>
                  <li>
                    On your computer or Android phone, open this app in <strong className="text-slate-100">Google Chrome</strong> (native Web Bluetooth support).
                  </li>
                  <li>
                    Click the blue <strong className="text-blue-400">"Connect Bluetooth Watch"</strong> button in the top navigation bar.
                  </li>
                  <li>
                    A pairing dialog will appear showing Bluetooth devices in range. Select your watch (typically advertising as <strong className="text-slate-100 font-mono">GL6113, BL6133, MX6XM, Smart Watch</strong>).
                  </li>
                  <li>
                    Once paired, ChronoSync BLE starts streaming the 128×128 pixel stream directly over the watch's BLE GATT characteristics!
                  </li>
                </ol>
              </div>

              <div className="p-3 bg-slate-800/40 rounded border border-slate-700/60 space-y-1">
                <span className="font-semibold text-slate-200 block">Why the 1.44" Simulator is Useful:</span>
                <p className="text-slate-400">
                  Even before or without connecting physical hardware, the simulator displays the exact 16-bit RGB565 downsampled output, delta tile compression savings, and raw BLE packet bytes in real time.
                </p>
              </div>
            </div>

            <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end">
              <button
                onClick={() => setShowHelpModal(false)}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
