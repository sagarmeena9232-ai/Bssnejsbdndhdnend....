/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ColorMode, CropMode, StreamEncodingSettings } from '../types/bluetooth';
import { 
  Sliders, 
  Layers, 
  Gauge, 
  Zap, 
  Crop, 
  Radio, 
  Sun, 
  Contrast, 
  RotateCcw,
  Sparkles
} from 'lucide-react';

interface EncodingControlsProps {
  settings: StreamEncodingSettings;
  setSettings: React.Dispatch<React.SetStateAction<StreamEncodingSettings>>;
}

export const EncodingControls: React.FC<EncodingControlsProps> = ({
  settings,
  setSettings
}) => {
  const updateSetting = <K extends keyof StreamEncodingSettings>(
    key: K,
    val: StreamEncodingSettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: val }));
  };

  const handleResetDefaults = () => {
    setSettings({
      targetResolution: 128,
      fpsLimit: 3,
      colorMode: 'rgb565',
      cropMode: 'center-crop',
      useDeltaCompression: true,
      tileSize: 16,
      mtuSize: 20,
      pacingIntervalMs: 15,
      brightness: 1.0,
      contrast: 1.0,
      invertColors: false
    });
  };

  return (
    <div className="bg-[#0F172A]/70 border border-slate-800 rounded-xl p-4 shadow-xl backdrop-blur-sm space-y-4">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-blue-400" />
          <h3 className="text-sm font-semibold tracking-tight text-slate-100">
            Wearable Stream & Compression Engine
          </h3>
        </div>
        <button
          onClick={handleResetDefaults}
          className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-200 transition-colors"
          title="Reset to 1.44'' GL6113 recommended defaults"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Defaults</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        {/* 1. Resolution & Framing */}
        <div className="space-y-2 bg-slate-900/60 p-3 rounded-lg border border-slate-800/80">
          <div className="flex items-center justify-between text-slate-300 font-medium">
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-blue-400" />
              1.44" Resolution
            </span>
          </div>
          <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded border border-slate-800">
            <button
              onClick={() => updateSetting('targetResolution', 128)}
              className={`py-1.5 px-2 text-xs font-mono font-medium rounded transition-colors ${
                settings.targetResolution === 128
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              128×128 (Native)
            </button>
            <button
              onClick={() => updateSetting('targetResolution', 240)}
              className={`py-1.5 px-2 text-xs font-mono font-medium rounded transition-colors ${
                settings.targetResolution === 240
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              240×240 (HD)
            </button>
          </div>

          <div className="pt-1">
            <span className="text-[11px] text-slate-400 block mb-1">Cropping Strategy:</span>
            <div className="grid grid-cols-3 gap-1 p-1 bg-slate-950 rounded border border-slate-800 text-[11px]">
              {(['center-crop', 'letterbox', 'cursor-track'] as CropMode[]).map(mode => (
                <button
                  key={mode}
                  onClick={() => updateSetting('cropMode', mode)}
                  className={`py-1 px-1 text-center capitalize rounded transition-colors truncate ${
                    settings.cropMode === mode
                      ? 'bg-blue-600 text-white font-medium'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {mode.replace('-', ' ')}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 2. Color Depth & Quantization */}
        <div className="space-y-2 bg-slate-900/60 p-3 rounded-lg border border-slate-800/80">
          <div className="flex items-center justify-between text-slate-300 font-medium">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              Color Bit-Depth
            </span>
            <span className="font-mono text-[10px] text-slate-400 uppercase">
              {settings.colorMode === 'rgb565' ? '16-bit' : settings.colorMode === 'rgb332' ? '8-bit' : 'Low BW'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded border border-slate-800">
            {(['rgb565', 'rgb332', 'grayscale', 'monochrome'] as ColorMode[]).map(mode => (
              <button
                key={mode}
                onClick={() => updateSetting('colorMode', mode)}
                className={`py-1 px-1.5 text-xs font-mono rounded transition-colors uppercase ${
                  settings.colorMode === mode
                    ? 'bg-blue-600 text-white font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          {/* Delta Compression Toggle */}
          <div className="pt-1 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-300 font-medium block">Delta Tile Engine</span>
              <span className="text-[10px] text-slate-500">Only sends modified 16×16 blocks</span>
            </div>
            <button
              onClick={() => updateSetting('useDeltaCompression', !settings.useDeltaCompression)}
              className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                settings.useDeltaCompression
                  ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/50'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              {settings.useDeltaCompression ? 'Active (70% Sav)' : 'Disabled'}
            </button>
          </div>
        </div>

        {/* 3. Framerate & BLE Bandwidth Budget */}
        <div className="space-y-2 bg-slate-900/60 p-3 rounded-lg border border-slate-800/80">
          <div className="flex items-center justify-between text-slate-300 font-medium">
            <span className="flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-emerald-400" />
              Framerate Limiter
            </span>
            <span className="font-mono text-blue-400 font-semibold">{settings.fpsLimit} FPS</span>
          </div>

          <div className="grid grid-cols-5 gap-1 p-1 bg-slate-950 rounded border border-slate-800 text-center font-mono">
            {[1, 2, 3, 5, 10].map(fps => (
              <button
                key={fps}
                onClick={() => updateSetting('fpsLimit', fps)}
                className={`py-1 text-xs rounded transition-colors ${
                  settings.fpsLimit === fps
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {fps}
              </button>
            ))}
          </div>
          <span className="text-[10px] text-slate-500 block">
            3 FPS is ideal for standard 1.44" BLE GATT throughput (~4-8 KB/s).
          </span>

          <div className="pt-1 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">BLE Packet MTU:</span>
            <select
              value={settings.mtuSize}
              onChange={e => updateSetting('mtuSize', Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 rounded px-2 py-0.5 text-xs text-slate-200 font-mono"
            >
              <option value={20}>20 Bytes (Standard BLE 4.0)</option>
              <option value={64}>64 Bytes (Expanded)</option>
              <option value={128}>128 Bytes (Fast)</option>
              <option value={244}>244 Bytes (BLE 4.2 DLE)</option>
            </select>
          </div>
        </div>

        {/* 4. Display & Contrast Calibration */}
        <div className="space-y-2 bg-slate-900/60 p-3 rounded-lg border border-slate-800/80">
          <div className="flex items-center justify-between text-slate-300 font-medium">
            <span className="flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-300" />
              TFT Calibration
            </span>
            <button
              onClick={() => updateSetting('invertColors', !settings.invertColors)}
              className={`text-[10px] px-1.5 py-0.5 rounded border ${
                settings.invertColors 
                  ? 'bg-purple-600/30 text-purple-300 border-purple-500/50' 
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              Invert
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Brightness</span>
              <span className="font-mono text-slate-300">{settings.brightness.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="1.5"
              step="0.1"
              value={settings.brightness}
              onChange={e => updateSetting('brightness', Number(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Contrast</span>
              <span className="font-mono text-slate-300">{settings.contrast.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="1.5"
              step="0.1"
              value={settings.contrast}
              onChange={e => updateSetting('contrast', Number(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
