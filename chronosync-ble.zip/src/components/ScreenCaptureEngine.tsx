/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { StreamEncodingSettings, TelemetryMetrics } from '../types/bluetooth';
import { bleSyncEngine } from '../services/bleProtocol';
import { 
  Monitor, 
  ScreenShare, 
  StopCircle, 
  Tv, 
  Crosshair, 
  Compass, 
  Sparkles,
  Maximize2,
  RefreshCw,
  Eye
} from 'lucide-react';

interface ScreenCaptureEngineProps {
  settings: StreamEncodingSettings;
  onTelemetryUpdate: (metrics: Partial<TelemetryMetrics>) => void;
  isStreaming: boolean;
  setIsStreaming: (streaming: boolean) => void;
}

export const ScreenCaptureEngine: React.FC<ScreenCaptureEngineProps> = ({
  settings,
  onTelemetryUpdate,
  isStreaming,
  setIsStreaming
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const sourceCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const targetCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [streamActive, setStreamActive] = useState<boolean>(false);
  const [activeSourceType, setActiveSourceType] = useState<'screen' | 'test_hud' | 'test_bars' | 'test_clock'>('test_hud');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0.5, y: 0.5 });
  const [sourceDimensions, setSourceDimensions] = useState<{ width: number; height: number }>({ width: 640, height: 480 });

  const mediaStreamRef = useRef<MediaStream | null>(null);
  const animationFrameIdRef = useRef<number | null>(null);
  const lastStreamTimestampRef = useRef<number>(0);
  const fpsCounterRef = useRef<{ count: number; lastTime: number; currentFps: number }>({
    count: 0,
    lastTime: Date.now(),
    currentFps: 0
  });

  // Start Screen Capture
  const handleStartCapture = async () => {
    setErrorMessage(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        throw new Error('Screen capture is not supported by your browser or inside this iframe. You can use the high-speed Test Pattern Generator below!');
      }

      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: 'monitor',
          frameRate: { max: settings.fpsLimit }
        },
        audio: false
      });

      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      stream.getVideoTracks()[0].addEventListener('ended', () => {
        handleStopCapture();
      });

      setStreamActive(true);
      setActiveSourceType('screen');
      setIsStreaming(true);
    } catch (err: any) {
      console.warn('Screen capture initiation:', err);
      if (err.name !== 'NotAllowedError') {
        setErrorMessage(err.message || 'Unable to access screen capture.');
      }
    }
  };

  // Stop Screen Capture
  const handleStopCapture = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setStreamActive(false);
    setActiveSourceType('test_hud');
  };

  // Switch to built-in wearable test cards
  const selectTestSource = (type: 'test_hud' | 'test_bars' | 'test_clock') => {
    if (streamActive) {
      handleStopCapture();
    }
    setActiveSourceType(type);
    setIsStreaming(true);
  };

  // Draw Built-in dynamic patterns
  const drawPattern = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number, type: string) => {
    const time = Date.now() / 1000;

    if (type === 'test_hud') {
      // Futuristic / Wearable HUD Dashboard test pattern
      ctx.fillStyle = '#060B14';
      ctx.fillRect(0, 0, width, height);

      // Subtle cyber grid
      ctx.strokeStyle = '#112240';
      ctx.lineWidth = 1;
      const step = 20;
      for (let x = 0; x < width; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Rotating radar circle in center
      const cx = width / 2;
      const cy = height / 2;
      const r = Math.min(width, height) * 0.35;

      ctx.strokeStyle = '#2563EB';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();

      // Sweeping radar arm
      const angle = time * 2;
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r);
      ctx.stroke();

      // Telemetry text
      ctx.fillStyle = '#60A5FA';
      ctx.font = 'bold 16px "JetBrains Mono", monospace';
      ctx.fillText('GL6113 SYNC', 20, 36);

      ctx.fillStyle = '#94A3B8';
      ctx.font = '12px "JetBrains Mono", monospace';
      ctx.fillText(`RES: ${settings.targetResolution}×${settings.targetResolution}`, 20, 56);
      ctx.fillText(`COLOR: ${settings.colorMode.toUpperCase()}`, 20, 74);

      // Dynamic metrics
      ctx.fillStyle = '#10B981';
      ctx.fillText(`HEART: ${Math.round(72 + Math.sin(time) * 6)} BPM`, 20, height - 44);
      ctx.fillStyle = '#F59E0B';
      ctx.fillText(`SIGNAL: -${Math.round(62 + Math.cos(time * 0.5) * 5)} dBm`, 20, height - 26);

      // Moving ping target
      const px = cx + Math.cos(time * 1.2) * (r * 0.7);
      const py = cy + Math.sin(time * 1.2) * (r * 0.7);
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.arc(px, py, 4, 0, Math.PI * 2);
      ctx.fill();

    } else if (type === 'test_bars') {
      // SMPTE Color Calibration Bars
      const colors = ['#C0C0C0', '#C0C000', '#00C0C0', '#00C000', '#C000C0', '#C00000', '#0000C0'];
      const barWidth = width / colors.length;
      for (let i = 0; i < colors.length; i++) {
        ctx.fillStyle = colors[i];
        ctx.fillRect(i * barWidth, 0, barWidth, height * 0.75);
      }
      // Lower calibration gradient
      const grad = ctx.createLinearGradient(0, height * 0.75, width, height * 0.75);
      grad.addColorStop(0, '#000000');
      grad.addColorStop(0.5, '#808080');
      grad.addColorStop(1, '#FFFFFF');
      ctx.fillStyle = grad;
      ctx.fillRect(0, height * 0.75, width, height * 0.25);

      // Centered label
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 20px "Plus Jakarta Sans", sans-serif';
      ctx.fillText('RGB565 TEST', width / 2 - 60, height * 0.4);

    } else if (type === 'test_clock') {
      // Precision Smartwatch Analog/Digital Clock
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      const r = Math.min(width, height) * 0.38;

      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();

      // Dial hour ticks
      ctx.strokeStyle = '#94A3B8';
      for (let i = 0; i < 12; i++) {
        const a = (i * Math.PI) / 6;
        const x1 = cx + Math.cos(a) * (r - 8);
        const y1 = cy + Math.sin(a) * (r - 8);
        const x2 = cx + Math.cos(a) * r;
        const y2 = cy + Math.sin(a) * r;
        ctx.lineWidth = i % 3 === 0 ? 3 : 1;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }

      const now = new Date();
      const secAngle = (now.getSeconds() + now.getMilliseconds() / 1000) * (Math.PI / 30) - Math.PI / 2;
      const minAngle = now.getMinutes() * (Math.PI / 30) - Math.PI / 2;
      const hrAngle = ((now.getHours() % 12) + now.getMinutes() / 60) * (Math.PI / 6) - Math.PI / 2;

      // Minute hand
      ctx.strokeStyle = '#CBD5E1';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(minAngle) * (r * 0.75), cy + Math.sin(minAngle) * (r * 0.75));
      ctx.stroke();

      // Hour hand
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(hrAngle) * (r * 0.5), cy + Math.sin(hrAngle) * (r * 0.5));
      ctx.stroke();

      // Second hand
      ctx.strokeStyle = '#EF4444';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(cx - Math.cos(secAngle) * 12, cy - Math.sin(secAngle) * 12);
      ctx.lineTo(cx + Math.cos(secAngle) * (r * 0.85), cy + Math.sin(secAngle) * (r * 0.85));
      ctx.stroke();

      // Digital time below
      ctx.fillStyle = '#F8FAFC';
      ctx.font = 'bold 18px "JetBrains Mono", monospace';
      const timeStr = now.toLocaleTimeString();
      ctx.fillText(timeStr, cx - 45, cy + r + 30);
    }
  }, [settings.targetResolution, settings.colorMode]);

  // Main Render & Streaming Loop
  useEffect(() => {
    let isCancelled = false;

    const renderLoop = async (now: number) => {
      if (isCancelled) return;

      const intervalMs = 1000 / settings.fpsLimit;
      const elapsed = now - lastStreamTimestampRef.current;

      if (elapsed >= intervalMs) {
        lastStreamTimestampRef.current = now;

        const targetRes = settings.targetResolution; // 128 or 240
        const sourceCanvas = sourceCanvasRef.current;
        const targetCanvas = targetCanvasRef.current;
        const video = videoRef.current;

        if (targetCanvas) {
          if (targetCanvas.width !== targetRes || targetCanvas.height !== targetRes) {
            targetCanvas.width = targetRes;
            targetCanvas.height = targetRes;
          }

          const targetCtx = targetCanvas.getContext('2d', { willReadFrequently: true });

          if (targetCtx) {
            targetCtx.imageSmoothingEnabled = false;

            let srcW = 400;
            let srcH = 300;

            // Render active source to source canvas
            if (activeSourceType === 'screen' && video && video.readyState >= 2) {
              srcW = video.videoWidth || 640;
              srcH = video.videoHeight || 480;

              if (sourceCanvas) {
                if (sourceCanvas.width !== srcW || sourceCanvas.height !== srcH) {
                  sourceCanvas.width = srcW;
                  sourceCanvas.height = srcH;
                  setSourceDimensions({ width: srcW, height: srcH });
                }
                const srcCtx = sourceCanvas.getContext('2d');
                srcCtx?.drawImage(video, 0, 0, srcW, srcH);
              }
            } else {
              // Draw generated test card
              srcW = 480;
              srcH = 360;
              if (sourceCanvas) {
                if (sourceCanvas.width !== srcW || sourceCanvas.height !== srcH) {
                  sourceCanvas.width = srcW;
                  sourceCanvas.height = srcH;
                  setSourceDimensions({ width: srcW, height: srcH });
                }
                const srcCtx = sourceCanvas.getContext('2d');
                if (srcCtx) {
                  drawPattern(srcCtx, srcW, srcH, activeSourceType);
                }
              }
            }

            // Downsample and crop to 1.44" square targetCanvas
            if (sourceCanvas) {
              targetCtx.fillStyle = '#000000';
              targetCtx.fillRect(0, 0, targetRes, targetRes);

              if (settings.cropMode === 'center-crop') {
                // Center square crop
                const squareDim = Math.min(srcW, srcH);
                const sx = (srcW - squareDim) / 2;
                const sy = (srcH - squareDim) / 2;
                targetCtx.drawImage(
                  sourceCanvas,
                  sx, sy, squareDim, squareDim,
                  0, 0, targetRes, targetRes
                );
              } else if (settings.cropMode === 'letterbox') {
                // Letterbox: fit full screen maintaining aspect ratio
                const scale = Math.min(targetRes / srcW, targetRes / srcH);
                const dw = srcW * scale;
                const dh = srcH * scale;
                const dx = (targetRes - dw) / 2;
                const dy = (targetRes - dh) / 2;
                targetCtx.drawImage(sourceCanvas, 0, 0, srcW, srcH, dx, dy, dw, dh);
              } else if (settings.cropMode === 'cursor-track') {
                // Dynamic cursor magnifier: zoom in around mouse coordinates
                const zoomBox = Math.min(srcW, srcH) * 0.45; // 2x magnification
                let sx = mousePos.x * srcW - zoomBox / 2;
                let sy = mousePos.y * srcH - zoomBox / 2;
                sx = Math.max(0, Math.min(srcW - zoomBox, sx));
                sy = Math.max(0, Math.min(srcH - zoomBox, sy));

                targetCtx.drawImage(
                  sourceCanvas,
                  sx, sy, zoomBox, zoomBox,
                  0, 0, targetRes, targetRes
                );
              }

              // Stream frame to BLE GATT pipeline and calculate telemetry
              if (isStreaming) {
                const streamResult = await bleSyncEngine.processAndStreamFrame(targetCanvas, settings);

                // Update FPS & throughput telemetry
                fpsCounterRef.current.count++;
                const nowMs = Date.now();
                if (nowMs - fpsCounterRef.current.lastTime >= 1000) {
                  const sec = (nowMs - fpsCounterRef.current.lastTime) / 1000;
                  fpsCounterRef.current.currentFps = +(fpsCounterRef.current.count / sec).toFixed(1);
                  fpsCounterRef.current.count = 0;
                  fpsCounterRef.current.lastTime = nowMs;

                  const kbps = +(streamResult.bytesSent / 1024 * (fpsCounterRef.current.currentFps || 1)).toFixed(1);
                  const saved = streamResult.rawFrameBytes > 0
                    ? Math.round((1 - (streamResult.bytesSent / streamResult.rawFrameBytes)) * 100)
                    : 0;

                  onTelemetryUpdate({
                    currentFps: fpsCounterRef.current.currentFps,
                    dataRateKbps: kbps,
                    totalBytesTransmitted: streamResult.bytesSent,
                    deltaTilesSent: streamResult.deltaTilesUpdated,
                    totalTilesInFrame: streamResult.totalTiles,
                    bandwidthSavedPercent: Math.max(0, saved),
                    uncompressedFrameSizeBytes: streamResult.rawFrameBytes,
                    compressedFrameSizeBytes: streamResult.bytesSent
                  });
                }
              }
            }
          }
        }
      }

      animationFrameIdRef.current = requestAnimationFrame(renderLoop);
    };

    animationFrameIdRef.current = requestAnimationFrame(renderLoop);

    return () => {
      isCancelled = true;
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
    };
  }, [settings, isStreaming, activeSourceType, mousePos, drawPattern, onTelemetryUpdate]);

  // Track mouse coordinates on source canvas
  const handleMouseMoveOnSource = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
    setMousePos({ x, y });
  };

  return (
    <div className="flex flex-col h-full bg-[#0F172A]/70 border border-slate-800 rounded-xl overflow-hidden shadow-2xl backdrop-blur-sm">
      {/* Panel Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800/80 bg-slate-900/60">
        <div className="flex items-center gap-2">
          <Monitor className="w-4 h-4 text-blue-400" />
          <h2 className="text-sm font-semibold tracking-tight text-slate-100">
            Desktop Screen Source
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {sourceDimensions.width}×{sourceDimensions.height}
          </span>
        </div>

        {/* Source Mode Selectors */}
        <div className="flex items-center gap-1.5">
          {!streamActive ? (
            <button
              onClick={handleStartCapture}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-colors"
            >
              <ScreenShare className="w-3.5 h-3.5" />
              <span>Share Screen / Window</span>
            </button>
          ) : (
            <button
              onClick={handleStopCapture}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-300 bg-rose-950/80 hover:bg-rose-900/80 border border-rose-800 rounded-lg transition-colors"
            >
              <StopCircle className="w-3.5 h-3.5" />
              <span>Stop Share</span>
            </button>
          )}
        </div>
      </div>

      {/* Video Element for screen stream (hidden, drawn to canvas) */}
      <video ref={videoRef} autoPlay playsInline muted className="hidden" />

      {/* Offscreen Target Canvas (128x128 / 240x240 for downsampling) */}
      <canvas ref={targetCanvasRef} className="hidden" />

      {/* Main Source Monitor View */}
      <div className="relative flex-1 flex flex-col items-center justify-center p-4 bg-slate-950 overflow-hidden">
        {errorMessage && (
          <div className="mb-3 px-3 py-2 bg-amber-950/60 border border-amber-800 rounded-lg text-amber-200 text-xs w-full max-w-md text-center">
            {errorMessage}
          </div>
        )}

        <div className="relative max-w-full max-h-full flex items-center justify-center rounded-lg overflow-hidden border border-slate-800 bg-slate-900/50 shadow-inner group">
          {/* Source Monitor Canvas */}
          <canvas
            ref={sourceCanvasRef}
            onMouseMove={handleMouseMoveOnSource}
            className="max-w-full max-h-[380px] object-contain cursor-crosshair"
          />

          {/* Cursor Magnifier Target Box Overlay (when in cursor-track mode) */}
          {settings.cropMode === 'cursor-track' && (
            <div
              className="absolute pointer-events-none border-2 border-blue-400 bg-blue-500/10 shadow-[0_0_15px_rgba(59,130,246,0.5)] rounded"
              style={{
                width: '120px',
                height: '120px',
                left: `calc(${mousePos.x * 100}% - 60px)`,
                top: `calc(${mousePos.y * 100}% - 60px)`,
                transition: 'width 0.1s, height 0.1s'
              }}
            >
              <Crosshair className="w-4 h-4 text-blue-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-70" />
            </div>
          )}

          {/* Center Crop Box Overlay Indicator */}
          {settings.cropMode === 'center-crop' && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="aspect-square h-full max-h-full border-2 border-emerald-400/40 border-dashed rounded bg-emerald-500/5" />
            </div>
          )}
        </div>

        {/* Source Mode Quick Toggles */}
        <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
          <span className="text-[11px] text-slate-400 font-medium">Wearable Test Feeds:</span>
          
          <button
            onClick={() => selectTestSource('test_hud')}
            className={`px-2.5 py-1 text-xs rounded transition-colors ${
              activeSourceType === 'test_hud' 
                ? 'bg-blue-600/30 text-blue-300 border border-blue-500/50' 
                : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
            }`}
          >
            HUD Telemetry
          </button>

          <button
            onClick={() => selectTestSource('test_clock')}
            className={`px-2.5 py-1 text-xs rounded transition-colors ${
              activeSourceType === 'test_clock' 
                ? 'bg-blue-600/30 text-blue-300 border border-blue-500/50' 
                : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
            }`}
          >
            Analog Clock
          </button>

          <button
            onClick={() => selectTestSource('test_bars')}
            className={`px-2.5 py-1 text-xs rounded transition-colors ${
              activeSourceType === 'test_bars' 
                ? 'bg-blue-600/30 text-blue-300 border border-blue-500/50' 
                : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
            }`}
          >
            SMPTE Color Bars
          </button>
        </div>
      </div>

      {/* Bottom Sub-bar */}
      <div className="px-4 py-2.5 bg-slate-900/90 border-t border-slate-800/80 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 text-slate-400">
          <Compass className="w-3.5 h-3.5 text-blue-400" />
          <span>Framing:</span>
          <span className="text-slate-200 font-mono font-medium capitalize">
            {settings.cropMode.replace('-', ' ')}
          </span>
        </div>

        <div className="text-[11px] text-slate-500">
          Tip: Move cursor across preview when in <span className="text-slate-300 font-mono">cursor-track</span> mode
        </div>
      </div>
    </div>
  );
};
