/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { exportProjectZip } from '../utils/sourceExporter';
import { downloadApkFile } from '../utils/apkGenerator';
import { 
  Download, 
  Smartphone, 
  CheckCircle2, 
  FileCode, 
  Bluetooth, 
  Share2, 
  Copy, 
  ExternalLink, 
  Package, 
  Layers,
  Sparkles,
  ShieldCheck
} from 'lucide-react';

interface InstallDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallDownloadModal: React.FC<InstallDownloadModalProps> = ({
  isOpen,
  onClose
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  // Direct Application Links
  const directApkUrl = 'https://ais-dev-tojaopw564uawai3zvh2pv-936609393261.asia-southeast1.run.app/chronosync-ble.apk';
  const devAppUrl = 'https://ais-dev-tojaopw564uawai3zvh2pv-936609393261.asia-southeast1.run.app';
  const sharedAppUrl = 'https://ais-pre-tojaopw564uawai3zvh2pv-936609393261.asia-southeast1.run.app';
  const fitProPlayStoreUrl = 'https://play.google.com/store/apps/details?id=cn.xiaofenglin.fitpro';
  const mtkBtNotificationUrl = 'https://play.google.com/store/apps/details?id=com.mtk.btnotification';

  const handleCopy = async (key: string, url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2500);
    } catch {
      // Fallback
    }
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    }
  };

  const handleClientApkDownload = async () => {
    try {
      await downloadApkFile();
    } catch (err) {
      console.error('Client APK download error:', err);
    }
  };

  const handleExportZip = async () => {
    try {
      setIsExporting(true);
      await exportProjectZip();
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (err) {
      console.error('Export failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center">
              <Package className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100 text-sm">Download APK & Android Installation</h3>
              <p className="text-[11px] text-slate-400">Direct standalone APK file with zero external dependencies</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-white px-2 py-1 rounded hover:bg-slate-800 text-sm"
          >
            ✕
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          
          {/* Section 1: 100% Working Direct APK Download */}
          <div className="p-4 bg-gradient-to-r from-emerald-950/50 via-slate-900 to-emerald-950/40 border border-emerald-500/50 rounded-xl space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold text-emerald-200 text-sm">Direct .APK File Download (Guaranteed)</span>
              </div>
              <span className="text-[10px] text-emerald-300 font-mono bg-emerald-900/40 border border-emerald-600/50 px-2 py-0.5 rounded">
                Direct File
              </span>
            </div>

            <p className="text-slate-300 leading-relaxed">
              Downloads <strong className="text-emerald-300 font-mono">chronosync-ble.apk</strong> directly from our origin server with no external converter or crawler bots required.
            </p>

            <div className="flex flex-col sm:flex-row gap-2">
              <a
                href="/chronosync-ble.apk"
                download="chronosync-ble.apk"
                className="flex-1 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-lg shadow-lg flex items-center justify-center gap-2 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Download chronosync-ble.apk</span>
              </a>

              <button
                onClick={handleClientApkDownload}
                className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs rounded-lg border border-slate-700 flex items-center justify-center gap-1.5 transition-colors"
                title="Generates APK inside your browser"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>Instant In-Browser APK</span>
              </button>
            </div>

            {/* Direct Link Input */}
            <div className="pt-1 space-y-1">
              <span className="text-[10px] text-slate-400 font-medium">Direct APK Download Link (paste into Chrome):</span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={directApkUrl}
                  className="flex-1 bg-slate-950 border border-slate-700/80 rounded px-2.5 py-1.5 font-mono text-[10px] text-slate-200 select-all focus:outline-none"
                />
                <button
                  onClick={() => handleCopy('apk', directApkUrl)}
                  className={`px-3 py-1.5 rounded font-medium text-xs flex items-center gap-1.5 transition-colors shrink-0 ${
                    copiedKey === 'apk'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  {copiedKey === 'apk' ? <CheckCircle2 className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'apk' ? 'Copied!' : 'Copy APK Link'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Section 2: Chrome Android WebAPK (Automatic System App) */}
          <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                Option 2: Install as Android WebAPK via Chrome
              </span>
              {isInstalled && (
                <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/60 border border-emerald-800 px-1.5 py-0.5 rounded">
                  Installed
                </span>
              )}
            </div>

            <p className="text-slate-400 text-[11px]">
              If opened on your phone in Google Chrome, you can also install the official WebAPK directly without downloading files manually:
            </p>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={devAppUrl}
                className="flex-1 bg-slate-950 border border-slate-700/80 rounded px-2.5 py-1.5 font-mono text-[10px] text-slate-300 select-all focus:outline-none"
              />
              <button
                onClick={() => handleCopy('app', devAppUrl)}
                className={`px-3 py-1.5 rounded font-medium text-xs flex items-center gap-1 transition-colors shrink-0 ${
                  copiedKey === 'app'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-blue-600 hover:bg-blue-500 text-white'
                }`}
              >
                {copiedKey === 'app' ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'app' ? 'Copied!' : 'Copy App Link'}</span>
              </button>
            </div>

            {isInstallable && (
              <button
                onClick={handleInstallClick}
                className="w-full mt-1 py-2 px-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-lg shadow flex items-center justify-center gap-2 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Tap to Install WebAPK onto this Android device</span>
              </button>
            )}
          </div>

          {/* Section 3: Official Factory Companion APKs for GL6113 Watch */}
          <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                Option 3: Official Factory Companion Apps (Google Play)
              </span>
              <span className="text-[10px] text-slate-400 font-mono">GL6113-WR/WB</span>
            </div>

            <p className="text-slate-400 text-[11px]">
              Standard companion APKs manufactured for your 1.44" watch hardware:
            </p>

            <div className="flex flex-wrap gap-2 pt-0.5">
              <a
                href={fitProPlayStoreUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded border border-slate-700 text-xs transition-colors"
              >
                <span>FitPro (Google Play)</span>
                <ExternalLink className="w-3 h-3 text-purple-400" />
              </a>

              <a
                href={mtkBtNotificationUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded border border-slate-700 text-xs transition-colors"
              >
                <span>MediaTek BTNotification</span>
                <ExternalLink className="w-3 h-3 text-purple-400" />
              </a>
            </div>
          </div>

          {/* Section 4: Source Code ZIP */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
            <div>
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-indigo-400" />
                Source Code Bundle (.ZIP)
              </span>
              <p className="text-slate-400 text-[10px]">All source files to run offline</p>
            </div>
            <button
              onClick={handleExportZip}
              disabled={isExporting}
              className="py-1 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-medium text-xs rounded border border-slate-700 flex items-center gap-1.5 transition-colors shrink-0"
            >
              <Download className="w-3 h-3 text-indigo-400" />
              <span>{isExporting ? 'Zipping...' : exportSuccess ? 'Downloaded!' : 'Download .zip'}</span>
            </button>
          </div>

        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">ChronoSync BLE Android Distribution</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
