/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { BluetoothConnectionState, StreamEncodingSettings } from '../types/bluetooth';
import { bleSyncEngine, USER_WATCH_PROFILE } from '../services/bleProtocol';
import { 
  Bluetooth, 
  BatteryMedium, 
  ZoomIn, 
  ZoomOut, 
  Grid, 
  Info, 
  Maximize2,
  Cpu,
  Radio,
  Sliders
} from 'lucide-react';

interface WatchBezelSimulatorProps {
  connectionState: BluetoothConnectionState;
  deviceName?: string;
  settings: StreamEncodingSettings;
  fps: number;
  dataRateKbps: number;
}

export const WatchBezelSimulator: React.FC<WatchBezelSimulatorProps> = ({
  connectionState,
  deviceName,
  settings,
  fps,
  dataRateKbps
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1.75);
  const [showPixelGrid, setShowPixelGrid] = useState<boolean>(true);
  const [showSpecModal, setShowSpecModal] = useState<boolean>(false);
  const [lastFrameTime, setLastFrameTime] = useState<number>(Date.now());
  const [isReceivingPackets, setIsReceivingPackets] = useState<boolean>(false);
  const [watchTime, setWatchTime] = useState<string>('');

  // Update simulated watch clock every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setWatchTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Listen to decoded frames from the loopback BLE engine
  useEffect(() => {
    const unsubscribe = bleSyncEngine.onSimulatedFrameDecoded((imageData, width, height) => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.putImageData(imageData, 0, 0);
      }

      setLastFrameTime(Date.now());
      setIsReceivingPackets(true);
      setTimeout(() => setIsReceivingPackets(false), 250);
    });

    return () => unsubscribe();
  }, []);

  const resolution = settings.targetResolution;

  return (
    <div className="flex flex-col h-full bg-[#0F172A]/70 border border-slate-800 rounded-xl overflow-hidden shadow-2xl backdrop-blur-sm">
      {/* Panel Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800/80 bg-slate-900/60">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <h2 className="text-sm font-semibold tracking-tight text-slate-100">
            1.44" Hardware Watch Unit
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {USER_WATCH_PROFILE.displayType}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowSpecModal(true)}
            className="flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
            title="Inspect Watch Firmware & Profile"
          >
            <Info className="w-3.5 h-3.5 text-blue-400" />
            <span>Profile</span>
          </button>

          <button
            onClick={() => setShowPixelGrid(!showPixelGrid)}
            className={`p-1 text-xs rounded transition-colors ${
              showPixelGrid 
                ? 'bg-blue-600/30 text-blue-300 border border-blue-500/50' 
                : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
            }`}
            title="Toggle TFT Sub-Pixel Grid"
          >
            <Grid className="w-3.5 h-3.5" />
          </button>

          <div className="flex items-center bg-slate-800 border border-slate-700 rounded overflow-hidden">
            <button
              onClick={() => setZoomLevel(prev => Math.max(1.0, +(prev - 0.25).toFixed(2)))}
              disabled={zoomLevel <= 1.0}
              className="p-1 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-1.5 text-[11px] font-mono text-slate-300 font-medium">
              {zoomLevel}x
            </span>
            <button
              onClick={() => setZoomLevel(prev => Math.min(2.5, +(prev + 0.25).toFixed(2)))}
              disabled={zoomLevel >= 2.5}
              className="p-1 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Watch Bezel Stage */}
      <div className="relative flex-1 flex items-center justify-center p-6 bg-gradient-to-b from-[#090D16] via-[#0E1422] to-[#090D16] overflow-auto">
        
        {/* Watch Chassis Container */}
        <div 
          className="relative transition-transform duration-200 flex items-center justify-center select-none"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          {/* Top Strap Attachment */}
          <div className="absolute -top-12 w-28 h-14 bg-gradient-to-b from-neutral-900 to-neutral-800 rounded-t-lg border-t border-x border-neutral-700/60 shadow-inner flex flex-col items-center justify-start pt-1">
            <div className="w-16 h-1.5 rounded-full bg-neutral-950/70" />
            <div className="w-20 h-0.5 mt-1 bg-neutral-700/30" />
          </div>

          {/* Bottom Strap Attachment */}
          <div className="absolute -bottom-12 w-28 h-14 bg-gradient-to-t from-neutral-900 to-neutral-800 rounded-b-lg border-b border-x border-neutral-700/60 shadow-inner flex flex-col items-center justify-end pb-1">
            <div className="w-20 h-0.5 mb-1 bg-neutral-700/30" />
            <div className="w-16 h-1.5 rounded-full bg-neutral-950/70" />
          </div>

          {/* Physical Watch Case: Square 1.44" form factor with rounded corners */}
          <div className="relative z-10 w-[200px] h-[220px] bg-gradient-to-b from-neutral-700 via-neutral-800 to-neutral-950 rounded-[28px] p-[10px] shadow-[0_20px_50px_rgba(0,0,0,0.8),inset_0_1px_2px_rgba(255,255,255,0.25),inset_0_-2px_4px_rgba(0,0,0,0.8)] border border-neutral-600/50">
            
            {/* CNC Bezel Chamfer Ring */}
            <div className="relative w-full h-full bg-gradient-to-tr from-neutral-900 via-black to-neutral-900 rounded-[20px] p-[6px] border border-neutral-800 shadow-[inset_0_2px_8px_rgba(0,0,0,0.9)] flex flex-col items-center justify-center">

              {/* Watch Glass Surface */}
              <div className="relative w-[164px] h-[164px] bg-black rounded-[12px] overflow-hidden border border-neutral-800 shadow-[inset_0_0_12px_rgba(0,0,0,0.95)]">
                
                {/* 1.44" Active TFT LCD Screen Canvas */}
                <canvas
                  ref={canvasRef}
                  width={resolution}
                  height={resolution}
                  className="w-full h-full object-contain image-rendering-pixelated bg-black"
                  style={{
                    imageRendering: 'pixelated',
                    filter: `brightness(${settings.brightness}) contrast(${settings.contrast})`
                  }}
                />

                {/* Subpixel Matrix Grid Overlay */}
                {showPixelGrid && (
                  <div 
                    className="absolute inset-0 pointer-events-none opacity-20 mix-blend-screen"
                    style={{
                      backgroundImage: `
                        linear-gradient(to right, rgba(255,255,255,0.15) 1px, transparent 1px),
                        linear-gradient(to bottom, rgba(255,255,255,0.15) 1px, transparent 1px)
                      `,
                      backgroundSize: `${164 / resolution}px ${164 / resolution}px`
                    }}
                  />
                )}

                {/* Watch Top HUD Overlay Bar (Simulated MRE OS status bar) */}
                <div className="absolute top-0 inset-x-0 h-4 bg-gradient-to-b from-black/80 to-transparent flex items-center justify-between px-2 text-[9px] font-mono pointer-events-none">
                  <div className="flex items-center gap-1">
                    <Bluetooth className={`w-2.5 h-2.5 ${
                      connectionState === 'connected' 
                        ? 'text-emerald-400' 
                        : isReceivingPackets 
                          ? 'text-blue-400' 
                          : 'text-slate-500'
                    }`} />
                    <span className="text-[8px] text-slate-300 font-semibold">{watchTime}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    {isReceivingPackets && (
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-ping" />
                    )}
                    <BatteryMedium className="w-2.5 h-2.5 text-slate-300" />
                  </div>
                </div>

                {/* Subtle Glass Glare Highlight */}
                <div 
                  className="absolute inset-0 pointer-events-none opacity-25"
                  style={{
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0.05) 35%, transparent 60%)'
                  }}
                />
              </div>

              {/* Bottom Subtle Watch Brand Indicator */}
              <div className="mt-1 flex items-center gap-1 text-[8px] tracking-widest text-neutral-500 uppercase font-mono">
                <span>GL6113</span>
                <span>·</span>
                <span>1.44"</span>
              </div>
            </div>

            {/* Right Physical Digital Crown */}
            <div 
              className="absolute -right-3 top-12 w-3.5 h-9 bg-gradient-to-r from-neutral-800 via-neutral-600 to-neutral-700 rounded-r-md border-y border-r border-neutral-500/60 shadow-lg cursor-pointer hover:brightness-110 active:scale-95 transition-transform"
              title="Hardware Crown: Click to toggle Zoom"
              onClick={() => setZoomLevel(prev => (prev >= 2.25 ? 1.25 : +(prev + 0.5).toFixed(2)))}
            >
              <div className="h-full flex flex-col justify-between py-1 px-0.5">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="h-0.5 bg-neutral-900/80 rounded-full" />
                ))}
              </div>
            </div>

            {/* Lower Push Button */}
            <div 
              className="absolute -right-2 bottom-12 w-2 h-6 bg-gradient-to-r from-neutral-800 via-neutral-600 to-neutral-700 rounded-r-sm border border-neutral-600/70 shadow-md cursor-pointer hover:brightness-110 active:scale-95 transition-transform"
              title="Hardware Button: Reset / Clear screen"
              onClick={() => {
                const canvas = canvasRef.current;
                if (canvas) {
                  const ctx = canvas.getContext('2d');
                  ctx?.clearRect(0, 0, canvas.width, canvas.height);
                }
              }}
            />

            {/* Left Microphone / Sensor Pin */}
            <div className="absolute -left-1 top-24 w-1 h-2 rounded-l-full bg-neutral-900 border border-neutral-700" />
          </div>
        </div>
      </div>

      {/* Bottom Live Watch Status Bar */}
      <div className="px-4 py-2.5 bg-slate-900/90 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <Radio className={`w-3.5 h-3.5 ${isReceivingPackets ? 'text-blue-400 animate-pulse' : 'text-slate-500'}`} />
            <span className="text-slate-400">Stream Status:</span>
            <span className={`font-mono font-medium ${isReceivingPackets ? 'text-emerald-400' : 'text-slate-300'}`}>
              {isReceivingPackets ? 'Active Sync' : 'Standby'}
            </span>
          </div>

          <span className="text-slate-600">|</span>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Resolution:</span>
            <span className="font-mono text-slate-200">{resolution}×{resolution}</span>
            <span className="text-[10px] text-slate-400 font-mono">({settings.colorMode.toUpperCase()})</span>
          </div>
        </div>

        <div className="flex items-center gap-3 font-mono">
          <div className="text-slate-400">
            FPS: <span className="text-blue-400 font-semibold">{fps.toFixed(1)}</span>
          </div>
          <div className="text-slate-400">
            Speed: <span className="text-amber-400 font-semibold">{dataRateKbps.toFixed(1)} KB/s</span>
          </div>
        </div>
      </div>

      {/* Hardware Profile Modal */}
      {showSpecModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-blue-400" />
                <h3 className="font-semibold text-slate-100">Smartwatch Hardware Specifications</h3>
              </div>
              <button 
                onClick={() => setShowSpecModal(false)}
                className="text-slate-400 hover:text-white px-2 py-1 rounded hover:bg-slate-800 text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
              <div className="p-3 bg-blue-950/30 border border-blue-800/40 rounded-lg text-blue-200">
                <span className="font-semibold block mb-1">Configured for your exact watch:</span>
                This app is optimized for your MediaTek MRE smartwatch architecture with pure offline Bluetooth GATT communication.
              </div>

              <div className="grid grid-cols-2 gap-2 text-slate-300 font-mono">
                <div className="p-2.5 bg-slate-800/50 rounded border border-slate-700/60">
                  <span className="text-slate-400 text-[10px] block">Model / Version</span>
                  <span className="text-slate-100 font-semibold">{USER_WATCH_PROFILE.name}</span>
                </div>
                <div className="p-2.5 bg-slate-800/50 rounded border border-slate-700/60">
                  <span className="text-slate-400 text-[10px] block">Serial Number</span>
                  <span className="text-slate-100 font-semibold">{USER_WATCH_PROFILE.serialNumber}</span>
                </div>
                <div className="p-2.5 bg-slate-800/50 rounded border border-slate-700/60">
                  <span className="text-slate-400 text-[10px] block">Display Dimension</span>
                  <span className="text-slate-100 font-semibold">1.44" (128×128 native / 240×240)</span>
                </div>
                <div className="p-2.5 bg-slate-800/50 rounded border border-slate-700/60">
                  <span className="text-slate-400 text-[10px] block">Color Depth</span>
                  <span className="text-slate-100 font-semibold">16-bit RGB565 (65,536 colors)</span>
                </div>
                <div className="p-2.5 bg-slate-800/50 rounded border border-slate-700/60">
                  <span className="text-slate-400 text-[10px] block">Firmware Branch</span>
                  <span className="text-slate-100 font-semibold">{USER_WATCH_PROFILE.branch}</span>
                </div>
                <div className="p-2.5 bg-slate-800/50 rounded border border-slate-700/60">
                  <span className="text-slate-400 text-[10px] block">MRE Version / Build</span>
                  <span className="text-slate-100 font-semibold">MRE {USER_WATCH_PROFILE.mreVersion} ({USER_WATCH_PROFILE.buildTime})</span>
                </div>
              </div>

              <div className="p-3 bg-slate-800/30 rounded border border-slate-700/50">
                <span className="text-slate-400 text-[10px] block mb-1">Full Version Identifier</span>
                <p className="font-mono text-[11px] text-slate-300 break-all bg-slate-950 p-2 rounded border border-slate-800">
                  {USER_WATCH_PROFILE.versionString}
                </p>
              </div>

              <div className="p-3 bg-slate-800/30 rounded border border-slate-700/50 space-y-1">
                <span className="text-slate-200 font-semibold block">Bluetooth Connection Guidance:</span>
                <p className="text-slate-400">
                  1. Turn on Bluetooth on your smartwatch and ensure it is in pairing/discoverable mode.<br/>
                  2. Ensure your computer's Bluetooth is switched ON.<br/>
                  3. Click <strong className="text-blue-400">"Connect Bluetooth Watch"</strong> in the top bar to open the browser device selector.
                </p>
              </div>
            </div>

            <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end">
              <button
                onClick={() => setShowSpecModal(false)}
                className="px-4 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
              >
                Close Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
