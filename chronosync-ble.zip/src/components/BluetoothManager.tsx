/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BluetoothConnectionState } from '../types/bluetooth';
import { bleSyncEngine, KNOWN_BLE_SERVICES, USER_WATCH_PROFILE } from '../services/bleProtocol';
import { 
  Bluetooth, 
  BluetoothConnected, 
  BluetoothOff, 
  BluetoothSearching, 
  AlertCircle, 
  Settings2, 
  CheckCircle2, 
  Radio,
  WifiOff,
  ShieldCheck,
  HelpCircle
} from 'lucide-react';

interface BluetoothManagerProps {
  connectionState: BluetoothConnectionState;
  deviceName?: string;
}

export const BluetoothManager: React.FC<BluetoothManagerProps> = ({
  connectionState,
  deviceName
}) => {
  const [showConfigModal, setShowConfigModal] = useState<boolean>(false);
  const [selectedServiceUuid, setSelectedServiceUuid] = useState<string>(KNOWN_BLE_SERVICES[0].uuid);
  const [customUuid, setCustomUuid] = useState<string>('');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [connectError, setConnectError] = useState<string | null>(null);

  const isWebBluetoothSupported = bleSyncEngine.isWebBluetoothSupported();

  const handleConnect = async () => {
    setConnectError(null);
    setIsScanning(true);
    try {
      const targetUuid = customUuid.trim() || selectedServiceUuid;
      await bleSyncEngine.connect(targetUuid);
    } catch (err: any) {
      console.warn('Bluetooth pairing result:', err);
      if (err.name !== 'NotFoundError') {
        setConnectError(err.message || 'Bluetooth connection failed.');
      }
    } finally {
      setIsScanning(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      await bleSyncEngine.disconnect();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <>
      <div className="flex items-center gap-2">
        {/* Offline Badge */}
        <div 
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-400 font-medium"
          title="Direct peer-to-peer radio link. No internet connection needed on watch."
        >
          <WifiOff className="w-3.5 h-3.5 text-amber-400" />
          <span>Local BLE Radio Only</span>
        </div>

        {/* Connection State Button / Badge */}
        {connectionState === 'connected' ? (
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-950/40 border border-emerald-600/40 rounded-lg text-emerald-300 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <BluetoothConnected className="w-4 h-4 text-emerald-400" />
              <span>{deviceName || 'GL6113 Connected'}</span>
            </div>
            <button
              onClick={handleDisconnect}
              className="px-2.5 py-1.5 text-xs font-medium text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
            >
              Disconnect
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={handleConnect}
              disabled={isScanning || !isWebBluetoothSupported}
              className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:pointer-events-none rounded-lg shadow-md shadow-blue-900/30 transition-all hover:shadow-blue-600/20"
            >
              {isScanning ? (
                <>
                  <BluetoothSearching className="w-4 h-4 animate-spin text-blue-200" />
                  <span>Searching Watch...</span>
                </>
              ) : (
                <>
                  <Bluetooth className="w-4 h-4" />
                  <span>Connect Bluetooth Watch</span>
                </>
              )}
            </button>

            <button
              onClick={() => setShowConfigModal(true)}
              className="p-1.5 text-slate-400 hover:text-slate-200 bg-slate-800/80 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
              title="Bluetooth Protocol & Service UUID Settings"
            >
              <Settings2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Connect Error Toast if any */}
      {connectError && (
        <div className="fixed bottom-4 right-4 z-50 max-w-sm p-3 bg-rose-950/90 border border-rose-800 rounded-lg text-rose-200 text-xs shadow-xl flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-semibold block mb-0.5">Bluetooth Connection Alert</span>
            <p>{connectError}</p>
          </div>
          <button 
            onClick={() => setConnectError(null)}
            className="text-rose-400 hover:text-rose-200 font-bold ml-1"
          >
            ✕
          </button>
        </div>
      )}

      {/* Web Bluetooth Support Warning if on unsupported browser */}
      {!isWebBluetoothSupported && (
        <div className="fixed top-16 inset-x-4 max-w-2xl mx-auto z-40 p-3 bg-amber-950/90 border border-amber-700/80 rounded-lg text-amber-200 text-xs shadow-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              Web Bluetooth API is available in Google Chrome, Microsoft Edge, Opera, or Samsung Internet. You can still use the 1.44" simulator in full!
            </span>
          </div>
        </div>
      )}

      {/* Bluetooth Configuration Modal */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
              <div className="flex items-center gap-2">
                <Bluetooth className="w-4 h-4 text-blue-400" />
                <h3 className="font-semibold text-slate-100 text-sm">Bluetooth Protocol Setup</h3>
              </div>
              <button 
                onClick={() => setShowConfigModal(false)}
                className="text-slate-400 hover:text-white px-2 py-1 rounded hover:bg-slate-800 text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-blue-950/30 border border-blue-800/40 rounded-lg text-blue-200 space-y-1">
                <span className="font-semibold block">Device Target:</span>
                <p className="text-slate-300 font-mono">
                  {USER_WATCH_PROFILE.name} (SN: {USER_WATCH_PROFILE.serialNumber})
                </p>
                <p className="text-slate-400 text-[11px]">
                  Scans for advertisement names starting with <strong className="text-blue-300">GL6113, BL6133, MX6XM, Smart Watch</strong> or any paired BLE peripheral.
                </p>
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1.5">
                  Select BLE GATT Service Profile:
                </label>
                <div className="space-y-1.5">
                  {KNOWN_BLE_SERVICES.map(svc => (
                    <label 
                      key={svc.id}
                      className={`flex items-start gap-2.5 p-2 rounded border cursor-pointer transition-colors ${
                        selectedServiceUuid === svc.uuid 
                          ? 'bg-blue-950/40 border-blue-500/60 text-white' 
                          : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <input
                        type="radio"
                        name="service_uuid"
                        value={svc.uuid}
                        checked={selectedServiceUuid === svc.uuid}
                        onChange={() => setSelectedServiceUuid(svc.uuid)}
                        className="mt-0.5 text-blue-600 focus:ring-0"
                      />
                      <div>
                        <span className="font-semibold block">{svc.name}</span>
                        <span className="font-mono text-[10px] text-slate-400 block">{svc.uuid}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">
                  Or Custom 16-bit / 128-bit Service UUID:
                </label>
                <input
                  type="text"
                  placeholder="e.g. 0000fee7-0000-1000-8000-00805f9b34fb"
                  value={customUuid}
                  onChange={e => setCustomUuid(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-200 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="p-3 bg-slate-800/40 rounded border border-slate-700/50 space-y-1 text-slate-400 text-[11px]">
                <div className="flex items-center gap-1.5 text-slate-200 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Offline Transmission Guarantee</span>
                </div>
                <p>
                  No internet or WiFi is accessed by the watch. Packets are streamed point-to-point directly via your PC's Bluetooth radio.
                </p>
              </div>
            </div>

            <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">Settings auto-saved</span>
              <button
                onClick={() => {
                  setShowConfigModal(false);
                  handleConnect();
                }}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
              >
                Scan & Connect
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
