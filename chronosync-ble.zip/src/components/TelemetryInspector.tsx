/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BlePacketLogItem, TelemetryMetrics } from '../types/bluetooth';
import { bleSyncEngine } from '../services/bleProtocol';
import { 
  Activity, 
  Terminal, 
  Trash2, 
  Pause, 
  Play, 
  ArrowUpRight, 
  Database, 
  Zap,
  Layers,
  Radio
} from 'lucide-react';

interface TelemetryInspectorProps {
  metrics: TelemetryMetrics;
}

export const TelemetryInspector: React.FC<TelemetryInspectorProps> = ({
  metrics
}) => {
  const [packetLogs, setPacketLogs] = useState<BlePacketLogItem[]>([]);
  const [isLogPaused, setIsLogPaused] = useState<boolean>(false);

  useEffect(() => {
    const unsubscribe = bleSyncEngine.onPacketLog(packet => {
      if (!isLogPaused) {
        setPacketLogs(prev => [packet, ...prev.slice(0, 49)]); // keep last 50
      }
    });

    return () => unsubscribe();
  }, [isLogPaused]);

  return (
    <div className="bg-[#0F172A]/70 border border-slate-800 rounded-xl overflow-hidden shadow-xl backdrop-blur-sm">
      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-y sm:divide-y-0 divide-slate-800 border-b border-slate-800 text-xs">
        
        {/* BLE Speed */}
        <div className="p-3 bg-slate-900/40">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-blue-400" />
              BLE Radio Speed
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Max ~10KB/s</span>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold font-mono tabular-nums text-slate-100">
              {metrics.dataRateKbps.toFixed(1)}
            </span>
            <span className="text-xs text-slate-400 font-mono">KB/s</span>
          </div>
          {/* Progress bar toward 10 KB/s radio ceiling */}
          <div className="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
            <div 
              className={`h-full transition-all duration-300 ${
                metrics.dataRateKbps > 8 ? 'bg-amber-400' : 'bg-blue-500'
              }`}
              style={{ width: `${Math.min(100, (metrics.dataRateKbps / 10) * 100)}%` }}
            />
          </div>
        </div>

        {/* Compression Efficiency */}
        <div className="p-3 bg-slate-900/40">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
              Bandwidth Saved
            </span>
            <span className="text-[10px] text-emerald-400/80 font-mono">Delta Tiling</span>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold font-mono tabular-nums text-emerald-400">
              {metrics.bandwidthSavedPercent}%
            </span>
            <span className="text-xs text-slate-400 font-mono">less radio load</span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            Updated: {metrics.deltaTilesSent} / {metrics.totalTilesInFrame || 64} tiles
          </div>
        </div>

        {/* Total Bytes Transferred */}
        <div className="p-3 bg-slate-900/40">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-indigo-400" />
              Transferred
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Point-to-Point</span>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold font-mono tabular-nums text-slate-100">
              {metrics.totalBytesTransmitted > 1024 * 1024
                ? `${(metrics.totalBytesTransmitted / (1024 * 1024)).toFixed(2)} MB`
                : `${(metrics.totalBytesTransmitted / 1024).toFixed(1)} KB`}
            </span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            Frame Raw: {(metrics.uncompressedFrameSizeBytes / 1024).toFixed(1)} KB
          </div>
        </div>

        {/* Live Framerate */}
        <div className="p-3 bg-slate-900/40">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              Stream Framerate
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Target Sync</span>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold font-mono tabular-nums text-amber-400">
              {metrics.currentFps.toFixed(1)}
            </span>
            <span className="text-xs text-slate-400 font-mono">FPS</span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            Drop Count: 0 frames
          </div>
        </div>
      </div>

      {/* Packet Log Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900/80 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <Terminal className="w-3.5 h-3.5 text-slate-400" />
          <span className="font-semibold text-slate-300">Live Bluetooth GATT Packet Stream</span>
          <span className="text-[10px] font-mono text-slate-500">
            ({packetLogs.length} recent packets)
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsLogPaused(!isLogPaused)}
            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
              isLogPaused
                ? 'bg-amber-600/30 text-amber-300 border border-amber-500/50'
                : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
            }`}
          >
            {isLogPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
            <span>{isLogPaused ? 'Resume' : 'Pause'}</span>
          </button>

          <button
            onClick={() => setPacketLogs([])}
            className="p-1 text-slate-400 hover:text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
            title="Clear packet log"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Live Packet Log View */}
      <div className="h-44 overflow-y-auto bg-slate-950 p-2 font-mono text-[11px] space-y-1">
        {packetLogs.length === 0 ? (
          <div className="h-full flex items-center justify-center text-slate-600 italic">
            Waiting for screen capture frame stream to generate BLE packets...
          </div>
        ) : (
          packetLogs.map(pkt => (
            <div 
              key={pkt.id}
              className="flex items-center justify-between px-2 py-1 rounded bg-slate-900/60 hover:bg-slate-900 border border-slate-800/40 text-slate-300"
            >
              <div className="flex items-center gap-2 overflow-hidden">
                <span className="text-slate-500 text-[10px]">
                  {new Date(pkt.timestamp).toLocaleTimeString([], { hour12: false, fractionalSecondDigits: 2 } as any)}
                </span>
                
                <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                  pkt.type === 'FRAME_START' 
                    ? 'bg-blue-900/80 text-blue-300 border border-blue-700/60'
                    : pkt.type === 'TILE_DELTA'
                      ? 'bg-emerald-900/80 text-emerald-300 border border-emerald-700/60'
                      : pkt.type === 'HANDSHAKE'
                        ? 'bg-purple-900/80 text-purple-300 border border-purple-700/60'
                        : 'bg-slate-800 text-slate-400'
                }`}>
                  {pkt.type}
                </span>

                <span className="text-slate-400 text-[10px]">
                  #{pkt.seq.toString().padStart(3, '0')}
                </span>

                <span className="text-slate-300 truncate">
                  {pkt.hexSample}
                </span>
              </div>

              <div className="flex items-center gap-2 shrink-0 text-slate-400 text-[10px]">
                <span>{pkt.sizeBytes} B</span>
                <span className={`w-1.5 h-1.5 rounded-full ${
                  pkt.target === 'physical_ble' ? 'bg-emerald-400' : 'bg-cyan-400'
                }`} title={pkt.target === 'physical_ble' ? 'Physical Radio' : 'Loopback Sim'} />
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
