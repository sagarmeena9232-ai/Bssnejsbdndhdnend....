/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  BluetoothConnectionState,
  ColorMode,
  StreamEncodingSettings,
  WatchHardwareProfile,
  BlePacketLogItem
} from '../types/bluetooth';

// Default watch profile matching the user's specific hardware version
export const USER_WATCH_PROFILE: WatchHardwareProfile = {
  name: 'GL6113-WR / BL6133 Watch',
  versionString: 'MX6XM-1.44- A1-3023B0E- RQ-BL6133- GL6113-WR/WB- V01.12- 20241122',
  branch: '11BW1308MP / HDT6260D_11B',
  buildTime: '2024/11/22 17:55',
  serialNumber: 'SN001234567',
  mreVersion: '3100',
  nativeWidth: 128,
  nativeHeight: 128,
  colorDepth: 16,
  screenDiagonalInches: 1.44,
  displayType: '1.44" TFT LCD RGB565',
};

// Common BLE GATT Service UUIDs for smartwatches & serial bridges
export const KNOWN_BLE_SERVICES = [
  { id: 'nordic_uart', name: 'Nordic UART Service (NUS)', uuid: '6e400001-b5a3-f393-e0a9-e50e24dcca9e', tx: '6e400002-b5a3-f393-e0a9-e50e24dcca9e', rx: '6e400003-b5a3-f393-e0a9-e50e24dcca9e' },
  { id: 'mtk_wearable', name: 'MediaTek Wearable Service', uuid: '0000fee7-0000-1000-8000-00805f9b34fb', tx: '0000fec7-0000-1000-8000-00805f9b34fb', rx: '0000fec8-0000-1000-8000-00805f9b34fb' },
  { id: 'fitpro_service', name: 'GL6113 / FitPro Vendor Service', uuid: '0000fff0-0000-1000-8000-00805f9b34fb', tx: '0000fff1-0000-1000-8000-00805f9b34fb', rx: '0000fff2-0000-1000-8000-00805f9b34fb' },
  { id: 'custom_spp', name: 'Generic SPP-over-BLE', uuid: '0000ff01-0000-1000-8000-00805f9b34fb', tx: '0000ff02-0000-1000-8000-00805f9b34fb', rx: '0000ff03-0000-1000-8000-00805f9b34fb' }
];

// Protocol Packet Constants
export const PACKET_MAGIC_BYTE = 0xAA;
export const CMD_FRAME_START = 0x01;
export const CMD_RAW_CHUNK   = 0x02;
export const CMD_DELTA_TILE  = 0x03;
export const CMD_FRAME_END   = 0x04;
export const CMD_HEARTBEAT   = 0x05;
export const CMD_HANDSHAKE   = 0x10;

/**
 * Calculates a simple CRC8 checksum
 */
export function calculateCrc8(data: Uint8Array): number {
  let crc = 0x00;
  for (let i = 0; i < data.length; i++) {
    crc ^= data[i];
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x80) !== 0) {
        crc = ((crc << 1) ^ 0x07) & 0xFF;
      } else {
        crc = (crc << 1) & 0xFF;
      }
    }
  }
  return crc;
}

/**
 * Converts 8-bit R, G, B into 16-bit RGB565 integer (Big Endian)
 * High byte: RRRRRGGG, Low byte: GGGBBBBB
 */
export function rgbToRgb565(r: number, g: number, b: number): number {
  const r5 = (r >> 3) & 0x1F;
  const g6 = (g >> 2) & 0x3F;
  const b5 = (b >> 3) & 0x1F;
  return (r5 << 11) | (g6 << 5) | b5;
}

/**
 * Converts RGB565 16-bit integer back to 8-bit [R, G, B] for simulation decoding
 */
export function rgb565ToRgb(val: number): [number, number, number] {
  const r5 = (val >> 11) & 0x1F;
  const g6 = (val >> 5) & 0x3F;
  const b5 = val & 0x1F;
  const r = (r5 * 255) / 31;
  const g = (g6 * 255) / 63;
  const b = (b5 * 255) / 31;
  return [Math.round(r), Math.round(g), Math.round(b)];
}

/**
 * Converts 8-bit R, G, B into 8-bit RGB332 byte
 */
export function rgbToRgb332(r: number, g: number, b: number): number {
  return (r & 0xE0) | ((g & 0xE0) >> 3) | (b >> 6);
}

/**
 * Converts RGB332 back to [R, G, B]
 */
export function rgb332ToRgb(val: number): [number, number, number] {
  const r = ((val >> 5) & 0x07) * (255 / 7);
  const g = ((val >> 2) & 0x07) * (255 / 7);
  const b = (val & 0x03) * (255 / 3);
  return [Math.round(r), Math.round(g), Math.round(b)];
}

export type PacketCallback = (packet: BlePacketLogItem) => void;
export type FrameDecodedCallback = (imageData: ImageData, width: number, height: number) => void;

class BleSyncEngine {
  private device: any | null = null;
  private gattServer: any | null = null;
  private txCharacteristic: any | null = null;
  private connectionState: BluetoothConnectionState = 'disconnected';
  private connectionListeners: Array<(state: BluetoothConnectionState, deviceName?: string) => void> = [];
  private packetListeners: PacketCallback[] = [];
  private frameDecodedListeners: FrameDecodedCallback[] = [];

  private sequenceNumber = 0;
  private previousFrameRgb565: Uint16Array | null = null;
  private previousFrameWidth = 0;
  private previousFrameHeight = 0;
  private isTransmitting = false;
  private connectedDeviceName = '';
  private activeServiceUuid = '';

  constructor() {
    // Reset state
  }

  public isWebBluetoothSupported(): boolean {
    return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
  }

  public getConnectionState(): BluetoothConnectionState {
    return this.connectionState;
  }

  public getConnectedDeviceName(): string {
    return this.connectedDeviceName;
  }

  public onConnectionChange(listener: (state: BluetoothConnectionState, deviceName?: string) => void) {
    this.connectionListeners.push(listener);
    listener(this.connectionState, this.connectedDeviceName);
    return () => {
      this.connectionListeners = this.connectionListeners.filter(l => l !== listener);
    };
  }

  public onPacketLog(listener: PacketCallback) {
    this.packetListeners.push(listener);
    return () => {
      this.packetListeners = this.packetListeners.filter(l => l !== listener);
    };
  }

  public onSimulatedFrameDecoded(listener: FrameDecodedCallback) {
    this.frameDecodedListeners.push(listener);
    return () => {
      this.frameDecodedListeners = this.frameDecodedListeners.filter(l => l !== listener);
    };
  }

  private setConnectionState(state: BluetoothConnectionState, name: string = '') {
    this.connectionState = state;
    this.connectedDeviceName = name;
    this.connectionListeners.forEach(listener => listener(state, name));
  }

  private emitPacket(packet: BlePacketLogItem) {
    this.packetListeners.forEach(l => l(packet));
  }

  /**
   * Scans and pairs with the Bluetooth watch using Web Bluetooth API.
   * Tailored for GL6113, BL6133, and MRE wearable profiles.
   */
  public async connect(requestedServiceUuid?: string): Promise<boolean> {
    if (!this.isWebBluetoothSupported()) {
      throw new Error('Web Bluetooth is not supported in this browser. Please use Chrome, Edge, or Opera on Windows, Mac, Linux, or Android.');
    }

    try {
      this.setConnectionState('scanning');

      // Prepare filters tailored to user's hardware
      const serviceUuids = KNOWN_BLE_SERVICES.map(s => s.uuid);
      if (requestedServiceUuid && !serviceUuids.includes(requestedServiceUuid.toLowerCase())) {
        serviceUuids.push(requestedServiceUuid.toLowerCase());
      }

      const navBluetooth = (navigator as any).bluetooth;

      const device = await navBluetooth.requestDevice({
        filters: [
          { namePrefix: 'GL6113' },
          { namePrefix: 'GL6113-WR' },
          { namePrefix: 'GL6113-WB' },
          { namePrefix: 'BL6133' },
          { namePrefix: 'MX6XM' },
          { namePrefix: 'Watch' },
          { namePrefix: 'Smart' },
          { namePrefix: 'A1' },
          { namePrefix: 'MRE' },
        ],
        optionalServices: serviceUuids
      }).catch(async (err: any) => {
        // If specific name filters found nothing or user canceled specific search, offer all devices fallback
        if (err.name === 'NotFoundError') {
          return await navBluetooth.requestDevice({
            acceptAllDevices: true,
            optionalServices: serviceUuids
          });
        }
        throw err;
      });

      if (!device) {
        this.setConnectionState('disconnected');
        return false;
      }

      this.setConnectionState('connecting', device.name || 'Bluetooth Watch');
      this.device = device;

      device.addEventListener('gattserverdisconnected', () => {
        this.setConnectionState('disconnected');
        this.gattServer = null;
        this.txCharacteristic = null;
      });

      const server = await device.gatt.connect();
      this.gattServer = server;

      // Discover writable characteristic across known services
      let foundTx: any = null;
      for (const serviceInfo of KNOWN_BLE_SERVICES) {
        try {
          const service = await server.getPrimaryService(serviceInfo.uuid);
          const chars = await service.getCharacteristics();
          // Find characteristic with write or writeWithoutResponse property
          const writeChar = chars.find((c: any) => c.properties.write || c.properties.writeWithoutResponse);
          if (writeChar) {
            foundTx = writeChar;
            this.activeServiceUuid = serviceInfo.uuid;
            break;
          }
        } catch {
          // Continue scanning next candidate service
        }
      }

      // If specific service wasn't matched, try any accessible service
      if (!foundTx) {
        try {
          const services = await server.getPrimaryServices();
          for (const s of services) {
            const chars = await s.getCharacteristics();
            const writeChar = chars.find((c: any) => c.properties.write || c.properties.writeWithoutResponse);
            if (writeChar) {
              foundTx = writeChar;
              this.activeServiceUuid = s.uuid;
              break;
            }
          }
        } catch {
          // Handled below
        }
      }

      this.txCharacteristic = foundTx;
      this.setConnectionState('connected', device.name || 'GL6113 Smartwatch');

      // Send initial handshake packet
      await this.sendHandshakePacket();
      return true;

    } catch (error: any) {
      if (error.name === 'NotFoundError') {
        this.setConnectionState('disconnected');
        return false;
      }
      this.setConnectionState('error');
      throw error;
    }
  }

  public async disconnect(): Promise<void> {
    if (this.gattServer && this.gattServer.connected) {
      this.gattServer.disconnect();
    }
    this.device = null;
    this.gattServer = null;
    this.txCharacteristic = null;
    this.setConnectionState('disconnected');
  }

  private async sendRawBleBytes(data: Uint8Array, packetType: BlePacketLogItem['type']): Promise<void> {
    const seq = (this.sequenceNumber++) & 0xFF;
    const isPhysical = Boolean(this.txCharacteristic && this.gattServer?.connected);

    // Format packet log item
    const hex = Array.from(data.slice(0, 16))
      .map(b => b.toString(16).padStart(2, '0').toUpperCase())
      .join(' ') + (data.length > 16 ? ` ...(+${data.length - 16}B)` : '');

    const logItem: BlePacketLogItem = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
      seq,
      type: packetType,
      sizeBytes: data.length,
      hexSample: hex,
      target: isPhysical ? 'physical_ble' : 'simulator_loopback'
    };

    this.emitPacket(logItem);

    if (isPhysical && this.txCharacteristic) {
      try {
        if (this.txCharacteristic.writeValueWithoutResponse) {
          await this.txCharacteristic.writeValueWithoutResponse(data);
        } else {
          await this.txCharacteristic.writeValue(data);
        }
      } catch (err) {
        console.warn('Physical BLE characteristic write error:', err);
      }
    }
  }

  private async sendHandshakePacket(): Promise<void> {
    const payload = new Uint8Array([
      PACKET_MAGIC_BYTE,
      CMD_HANDSHAKE,
      0x01, // Version 1.0
      0x80, // 128x128 width
      0x80, // 128x128 height
      0x10, // 16-bit RGB565
      calculateCrc8(new Uint8Array([PACKET_MAGIC_BYTE, CMD_HANDSHAKE, 0x01, 0x80, 0x80, 0x10]))
    ]);
    await this.sendRawBleBytes(payload, 'HANDSHAKE');
  }

  /**
   * Encodes a canvas frame and streams it over BLE using MTU chunking and delta tiling
   */
  public async processAndStreamFrame(
    canvas: HTMLCanvasElement,
    settings: StreamEncodingSettings
  ): Promise<{
    bytesSent: number;
    deltaTilesUpdated: number;
    totalTiles: number;
    rawFrameBytes: number;
  }> {
    if (this.isTransmitting) {
      return { bytesSent: 0, deltaTilesUpdated: 0, totalTiles: 0, rawFrameBytes: 0 };
    }

    this.isTransmitting = true;

    try {
      const width = canvas.width;
      const height = canvas.height;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) {
        this.isTransmitting = false;
        return { bytesSent: 0, deltaTilesUpdated: 0, totalTiles: 0, rawFrameBytes: 0 };
      }

      const imgData = ctx.getImageData(0, 0, width, height);
      const rgba = imgData.data;
      const pixelCount = width * height;

      // 1. Convert to target color buffer
      const currentRgb565 = new Uint16Array(pixelCount);
      const currentRgb332 = new Uint8Array(pixelCount);

      for (let i = 0; i < pixelCount; i++) {
        const offset = i * 4;
        let r = rgba[offset];
        let g = rgba[offset + 1];
        let b = rgba[offset + 2];

        // Apply contrast & brightness adjustments
        if (settings.brightness !== 1.0 || settings.contrast !== 1.0) {
          r = Math.min(255, Math.max(0, ((r - 128) * settings.contrast + 128) * settings.brightness));
          g = Math.min(255, Math.max(0, ((g - 128) * settings.contrast + 128) * settings.brightness));
          b = Math.min(255, Math.max(0, ((b - 128) * settings.contrast + 128) * settings.brightness));
        }

        if (settings.invertColors) {
          r = 255 - r;
          g = 255 - g;
          b = 255 - b;
        }

        if (settings.colorMode === 'rgb565') {
          currentRgb565[i] = rgbToRgb565(r, g, b);
        } else if (settings.colorMode === 'rgb332') {
          currentRgb332[i] = rgbToRgb332(r, g, b);
        } else if (settings.colorMode === 'grayscale') {
          const lum = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
          currentRgb565[i] = rgbToRgb565(lum, lum, lum);
        } else if (settings.colorMode === 'monochrome') {
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          const bw = lum > 128 ? 255 : 0;
          currentRgb565[i] = rgbToRgb565(bw, bw, bw);
        }
      }

      // Calculate raw uncompressed frame size
      const rawBytesPerPixel = settings.colorMode === 'rgb332' ? 1 : 2;
      const rawFrameBytes = pixelCount * rawBytesPerPixel;
      let totalBytesSent = 0;
      let deltaTilesUpdated = 0;

      const tileSize = settings.tileSize || 16;
      const cols = Math.ceil(width / tileSize);
      const rows = Math.ceil(height / tileSize);
      const totalTiles = cols * rows;

      // 2. Decide between Full Frame Stream vs Delta Tile Stream
      const isInitialFrame = !this.previousFrameRgb565 || this.previousFrameWidth !== width || this.previousFrameHeight !== height;

      if (!settings.useDeltaCompression || isInitialFrame) {
        // Send FRAME_START packet
        const startPkt = new Uint8Array([
          PACKET_MAGIC_BYTE,
          CMD_FRAME_START,
          width & 0xFF,
          height & 0xFF,
          settings.colorMode === 'rgb332' ? 0x08 : 0x10,
          0x00 // Full Frame flag
        ]);
        await this.sendRawBleBytes(startPkt, 'FRAME_START');
        totalBytesSent += startPkt.length;

        // Chunk raw pixel buffer into MTU slices
        const payloadBytes = new Uint8Array(rawFrameBytes);
        if (settings.colorMode === 'rgb332') {
          payloadBytes.set(currentRgb332);
        } else {
          const view = new DataView(payloadBytes.buffer);
          for (let p = 0; p < pixelCount; p++) {
            view.setUint16(p * 2, currentRgb565[p], false); // Big-Endian for MRE
          }
        }

        const maxMtu = Math.max(20, Math.min(244, settings.mtuSize || 20));
        // Reserve 4 bytes for packet header: [MAGIC, CMD, CHUNK_SEQ, CHUNK_LEN]
        const chunkSize = maxMtu - 4;
        let chunkSeq = 0;

        for (let offset = 0; offset < payloadBytes.length; offset += chunkSize) {
          const slice = payloadBytes.subarray(offset, Math.min(offset + chunkSize, payloadBytes.length));
          const chunkPkt = new Uint8Array(4 + slice.length);
          chunkPkt[0] = PACKET_MAGIC_BYTE;
          chunkPkt[1] = CMD_RAW_CHUNK;
          chunkPkt[2] = (chunkSeq++) & 0xFF;
          chunkPkt[3] = slice.length;
          chunkPkt.set(slice, 4);

          await this.sendRawBleBytes(chunkPkt, 'FULL_CHUNK');
          totalBytesSent += chunkPkt.length;

          if (settings.pacingIntervalMs > 0) {
            await new Promise(r => setTimeout(r, settings.pacingIntervalMs));
          }
        }

        deltaTilesUpdated = totalTiles;
      } else {
        // Delta Tile Compression: scan 16x16 tiles
        const changedTileIndices: number[] = [];

        for (let tileY = 0; tileY < rows; tileY++) {
          for (let tileX = 0; tileX < cols; tileX++) {
            const tileIdx = tileY * cols + tileX;
            let tileDirty = false;

            const startX = tileX * tileSize;
            const startY = tileY * tileSize;
            const endX = Math.min(startX + tileSize, width);
            const endY = Math.min(startY + tileSize, height);

            // Compare pixels in tile against previous frame
            for (let y = startY; y < endY; y++) {
              const rowOffset = y * width;
              for (let x = startX; x < endX; x++) {
                const idx = rowOffset + x;
                if (currentRgb565[idx] !== this.previousFrameRgb565![idx]) {
                  tileDirty = true;
                  break;
                }
              }
              if (tileDirty) break;
            }

            if (tileDirty) {
              changedTileIndices.push(tileIdx);
            }
          }
        }

        deltaTilesUpdated = changedTileIndices.length;

        // If changes detected, send FRAME_START (Delta mode)
        if (changedTileIndices.length > 0) {
          const startPkt = new Uint8Array([
            PACKET_MAGIC_BYTE,
            CMD_FRAME_START,
            width & 0xFF,
            height & 0xFF,
            settings.colorMode === 'rgb332' ? 0x08 : 0x10,
            0x01, // Delta flag
            changedTileIndices.length & 0xFF
          ]);
          await this.sendRawBleBytes(startPkt, 'FRAME_START');
          totalBytesSent += startPkt.length;

          // Transmit each changed tile
          const maxMtu = Math.max(20, Math.min(244, settings.mtuSize || 20));
          const headerReserve = 5; // [MAGIC, CMD_DELTA, TILE_IDX, CHUNK_INDEX, LEN]
          const sliceCapacity = maxMtu - headerReserve;

          for (const tileIdx of changedTileIndices) {
            const tileX = (tileIdx % cols) * tileSize;
            const tileY = Math.floor(tileIdx / cols) * tileSize;
            const actualTileW = Math.min(tileSize, width - tileX);
            const actualTileH = Math.min(tileSize, height - tileY);
            const tilePixels = actualTileW * actualTileH;

            const tileBytes = new Uint8Array(tilePixels * rawBytesPerPixel);
            const tileView = new DataView(tileBytes.buffer);

            let ptr = 0;
            for (let ty = 0; ty < actualTileH; ty++) {
              const rowOffset = (tileY + ty) * width;
              for (let tx = 0; tx < actualTileW; tx++) {
                const pIdx = rowOffset + (tileX + tx);
                if (settings.colorMode === 'rgb332') {
                  tileBytes[ptr++] = currentRgb332[pIdx];
                } else {
                  tileView.setUint16(ptr, currentRgb565[pIdx], false);
                  ptr += 2;
                }
              }
            }

            // Packetize tile
            let tileChunkIndex = 0;
            for (let offset = 0; offset < tileBytes.length; offset += sliceCapacity) {
              const slice = tileBytes.subarray(offset, Math.min(offset + sliceCapacity, tileBytes.length));
              const tilePkt = new Uint8Array(headerReserve + slice.length);
              tilePkt[0] = PACKET_MAGIC_BYTE;
              tilePkt[1] = CMD_DELTA_TILE;
              tilePkt[2] = tileIdx & 0xFF;
              tilePkt[3] = (tileChunkIndex++) & 0xFF;
              tilePkt[4] = slice.length;
              tilePkt.set(slice, headerReserve);

              await this.sendRawBleBytes(tilePkt, 'TILE_DELTA');
              totalBytesSent += tilePkt.length;

              if (settings.pacingIntervalMs > 0) {
                await new Promise(r => setTimeout(r, settings.pacingIntervalMs));
              }
            }
          }
        }
      }

      // Send FRAME_END
      const endPkt = new Uint8Array([PACKET_MAGIC_BYTE, CMD_FRAME_END, 0x00]);
      await this.sendRawBleBytes(endPkt, 'FRAME_END');
      totalBytesSent += endPkt.length;

      // 3. Update previous frame memory
      this.previousFrameRgb565 = currentRgb565;
      this.previousFrameWidth = width;
      this.previousFrameHeight = height;

      // 4. Feed the loopback simulator with the EXACT decoded output
      // so the simulated 1.44" watch displays the exact color downsampling & quantization
      const simImgData = ctx.createImageData(width, height);
      const simData = simImgData.data;

      for (let p = 0; p < pixelCount; p++) {
        let r = 0, g = 0, b = 0;
        if (settings.colorMode === 'rgb332') {
          [r, g, b] = rgb332ToRgb(currentRgb332[p]);
        } else {
          [r, g, b] = rgb565ToRgb(currentRgb565[p]);
        }
        const o = p * 4;
        simData[o] = r;
        simData[o + 1] = g;
        simData[o + 2] = b;
        simData[o + 3] = 255;
      }

      this.frameDecodedListeners.forEach(l => l(simImgData, width, height));

      this.isTransmitting = false;
      return {
        bytesSent: totalBytesSent,
        deltaTilesUpdated,
        totalTiles,
        rawFrameBytes
      };
    } catch (err) {
      this.isTransmitting = false;
      console.error('Frame streaming pipeline error:', err);
      return { bytesSent: 0, deltaTilesUpdated: 0, totalTiles: 0, rawFrameBytes: 0 };
    }
  }
}

export const bleSyncEngine = new BleSyncEngine();
